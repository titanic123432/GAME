"""경찰과 도둑: 솔로 AI / 2인 멀티 / 서바이벌 듀오 모드를 지원하는 Pygame 추격전.

설치: pip install pygame
실행: python police_chase.py

모드
- 솔로모드: 플레이어 1명 + AI 1명
- 멀티모드: 경찰 vs 도둑 2인 대결
- 서바이벌 듀오: 도둑 2명(플레이어) vs AI 경찰 1명

공통 키
- SPACE: 게임 시작
- R: 새 랜덤 맵 준비
- M: 모드 선택 화면
- ESC: 게임 종료
"""

import math
import random
from collections import deque
from dataclasses import dataclass

import pygame

# ────────────────── 밸런스 설정 ──────────────────
WORLD_W, WORLD_H = 1760, 680
FPS = 60
ROUND_TIME = 80.0
CAR_SPEED = 205.0
CAR_HITBOX = 32
PORTAL_COOLDOWN = 1.0

ITEM_SPAWN_INTERVAL = 10.0
ITEM_LIFETIME = 5.0
ITEM_HITBOX = 30
BOOST_DURATION = 5.0              # 요청 반영: 6초 -> 5초
BOOST_MULTIPLIER = 1.30           # +30%
STUN_DURATION = 2.5               # 요청 반영: 3초 -> 2.5초
CHASE_TRIGGER_TIME = 15.0         # 남은 15초
CHASE_SPEED_BONUS = 0.10          # 경찰 +10%
CHASE_NOTICE_DURATION = 3.0

BG = (17, 23, 35)
PANEL = (27, 35, 51)
ROAD = (246, 248, 251)
WALL = (120, 126, 135)
WALL_EDGE = (94, 102, 113)
ROAD_MARK = (213, 219, 227)
POLICE_BLUE = (42, 158, 245)
THIEF_RED = (239, 64, 76)
THIEF_ORANGE = (246, 147, 48)
BOOST_GREEN = (31, 184, 91)
STUN_GOLD = (239, 172, 57)
WHITE = (246, 250, 255)
MUTED = (161, 173, 192)
PORTAL_COLORS = {
    "red": (250, 72, 82),
    "blue": (29, 166, 251),
    "green": (38, 194, 105),
    "purple": (176, 92, 204),
    "orange": (255, 153, 51),
}


@dataclass(frozen=True)
class Portal:
    name: str
    area: pygame.Rect
    exit_pos: tuple[int, int]
    exit_dir: tuple[int, int]


@dataclass(frozen=True)
class MapSpec:
    name: str
    walls: tuple[pygame.Rect, ...]
    portals: tuple[Portal, ...]
    police_start: tuple[int, int]
    thief_start: tuple[int, int]
    police_direction: tuple[int, int] = (0, 1)
    thief_direction: tuple[int, int] = (0, -1)


def create_map(name, walls, portals, police_start, thief_start,
               police_direction=(0, 1), thief_direction=(0, -1)):
    return MapSpec(
        name=name,
        walls=tuple(pygame.Rect(*data) for data in walls),
        portals=tuple(
            Portal(color, pygame.Rect(x, y, w, h), (out_x, out_y), (dx, dy))
            for color, x, y, w, h, out_x, out_y, dx, dy in portals
        ),
        police_start=police_start,
        thief_start=thief_start,
        police_direction=police_direction,
        thief_direction=thief_direction,
    )


MAP_1 = create_map(
    "기본 맵",
    [
        (0, 0, 310, 90), (380, 0, 490, 90), (940, 0, 565, 90),
        (1590, 0, 170, 90),
        (0, 150, 310, 365), (380, 150, 800, 155),
        (380, 365, 170, 145), (620, 358, 550, 142),
        (1260, 150, 130, 350), (1500, 145, 150, 160),
        (1500, 365, 150, 210),
        (0, 575, 415, 105), (490, 575, 385, 105),
        (940, 575, 710, 105),
    ],
    [
        ("red", 320, 12, 50, 62, 908, 542, 1, 0),
        ("red", 882, 608, 51, 66, 345, 118, 0, 1),
        ("blue", 880, 12, 50, 62, 452, 542, 1, 0),
        ("blue", 426, 608, 53, 66, 906, 120, 1, 0),
        ("green", 1515, 12, 63, 62, 80, 119, 1, 0),
        ("green", 6, 100, 48, 45, 1543, 118, -1, 0),
        ("purple", 6, 526, 48, 43, 1705, 537, 0, -1),
        ("purple", 1670, 608, 80, 66, 80, 548, 1, 0),
    ],
    (345, 331), (1444, 337),
)

MAP_2 = create_map(
    "우회로 맵",
    [
        (0, 0, 280, 90), (350, 0, 450, 90),
        (870, 0, 575, 90), (1535, 0, 225, 90),
        (0, 160, 280, 342),
        (360, 160, 690, 145), (360, 375, 200, 145),
        (650, 360, 500, 145), (1260, 165, 170, 325),
        (1510, 165, 140, 160), (1510, 380, 140, 195),
        (0, 575, 390, 105), (470, 575, 520, 105),
        (1060, 575, 600, 105),
    ],
    [
        ("red", 290, 12, 50, 62, 1023, 545, 1, 0),
        ("red", 1000, 608, 55, 66, 315, 125, 0, 1),
        ("blue", 810, 12, 50, 62, 430, 548, 1, 0),
        ("blue", 405, 608, 51, 66, 835, 125, 0, 1),
        ("green", 1460, 12, 58, 62, 80, 125, 1, 0),
        ("green", 6, 100, 48, 45, 1485, 125, -1, 0),
        ("purple", 6, 528, 48, 43, 1700, 540, 0, -1),
        ("purple", 1674, 608, 74, 66, 80, 545, 1, 0),
    ],
    (315, 331), (1465, 337),
)

MAP_3 = create_map(
    "교차로 맵",
    [
        (0, 0, 420, 90), (495, 0, 505, 90),
        (1080, 0, 470, 90), (1635, 0, 125, 90),
        (0, 165, 365, 350),
        (430, 165, 690, 135), (1200, 165, 120, 120),
        (430, 380, 170, 135), (680, 390, 570, 125),
        (1350, 165, 100, 315),
        (1530, 165, 135, 180), (1530, 405, 135, 170),
        (0, 575, 510, 105), (590, 575, 375, 105),
        (1035, 575, 630, 105),
    ],
    [
        ("red", 432, 12, 51, 62, 997, 544, 1, 0),
        ("red", 975, 608, 52, 66, 459, 126, 0, 1),
        ("blue", 1010, 12, 58, 62, 547, 545, 1, 0),
        ("blue", 522, 608, 55, 66, 1038, 126, 0, 1),
        ("green", 1564, 12, 58, 62, 80, 128, 1, 0),
        ("green", 6, 102, 48, 43, 1592, 127, -1, 0),
        ("purple", 6, 527, 48, 44, 1707, 539, 0, -1),
        ("purple", 1681, 608, 69, 66, 80, 546, 1, 0),
    ],
    (397, 335), (1490, 358),
)

MAP_4 = create_map(
    "이중 포털 맵",
    [
        (0, 0, 1460, 59), (1545, 0, 215, 680),
        (0, 113, 515, 138),
        (604, 110, 860, 105), (604, 215, 370, 34),
        (0, 321, 565, 166), (655, 318, 335, 169),
        (1065, 267, 400, 220),
        (0, 552, 786, 128), (878, 552, 600, 128),
    ],
    [
        ("blue", 7, 61, 49, 50, 95, 520, 1, 0),
        ("blue", 7, 489, 49, 61, 95, 87, 1, 0),
        ("red", 1466, 3, 72, 55, 1509, 607, 0, -1),
        ("red", 1480, 610, 57, 63, 1509, 92, 0, 1),
    ],
    (145, 519), (1509, 325),
    police_direction=(1, 0),
    thief_direction=(0, -1),
)

# 새 맵: 사용자가 제공한 스케치를 직선/직각 구조로 정리한 버전.
# 중앙 개활지 + 작은 중앙 장애물 + 좌/우 측면 포털, 하단 2연속 오렌지 포털 구조.
MAP_5 = create_map(
    "링 포털 맵",
    [
        (0, 0, 260, 232),            # 좌상단 큰 벽
        (1115, 112, 645, 324),       # 우상단 큰 벽
        (0, 285, 268, 161),          # 좌중단 벽
        (0, 519, 275, 161),          # 좌하단 벽
        (488, 198, 242, 122),        # 중앙 작은 벽
        (350, 515, 447, 165),        # 하단 좌측 큰 벽
        (868, 515, 138, 165),        # 하단 중앙 세로 벽
        (1093, 500, 667, 180),       # 하단 우측 큰 벽
    ],
    [
        ("red", 259, 4, 77, 56, 299, 602, 0, -1),
        ("red", 259, 610, 87, 64, 299, 90, 0, 1),
        ("blue", 4, 228, 52, 60, 1668, 87, -1, 0),
        ("blue", 1707, 47, 49, 71, 90, 255, 1, 0),
        ("green", 4, 442, 52, 80, 1668, 468, -1, 0),
        ("green", 1707, 436, 49, 80, 90, 468, 1, 0),
        ("orange", 785, 610, 76, 64, 1035, 600, 0, -1),
        ("orange", 982, 610, 76, 64, 824, 600, 0, -1),
    ],
    (423, 408), (1515, 89),
    police_direction=(1, 0),
    thief_direction=(-1, 0),
)

MAPS = (MAP_1, MAP_2, MAP_3, MAP_4, MAP_5)


@dataclass(frozen=True)
class Layout:
    screen_w: int
    screen_h: int
    scale: float
    map_x: int
    map_y: int
    header_h: int
    footer_h: int
    ui_scale: float

    def to_screen(self, point):
        return (round(self.map_x + point[0] * self.scale),
                round(self.map_y + point[1] * self.scale))


def compute_layout(screen_w, screen_h):
    ui = min(screen_w / 1440.0, screen_h / 720.0)
    header = max(72, round(100 * ui))
    footer = max(76, round(90 * ui))
    gap = max(12, round(24 * ui))
    scale = min(
        (screen_w - gap * 2) / WORLD_W,
        (screen_h - header - footer - gap) / WORLD_H,
    )
    scale = max(0.15, scale)
    map_x = round((screen_w - WORLD_W * scale) / 2)
    map_y = header + round((screen_h - header - footer - WORLD_H * scale) / 2)
    return Layout(screen_w, screen_h, scale, map_x, map_y, header, footer, ui)


class Car:
    def __init__(self, start, direction, color, label, level, role):
        self.pos = pygame.Vector2(start)
        self.direction = direction
        self.color = color
        self.label = label
        self.level = level
        self.role = role            # "police" 또는 "thief"
        self.teleport_cooldown = 0.0
        self.boost_left = 0.0
        self.stun_left = 0.0
        self.chase_active = False
        self.alive = True

    @property
    def move_speed(self):
        bonus = (BOOST_MULTIPLIER - 1.0) if self.boost_left > 0 else 0.0
        if self.role == "police" and self.chase_active:
            bonus += CHASE_SPEED_BONUS
        return CAR_SPEED * (1.0 + bonus)

    @staticmethod
    def hitbox_at(x, y):
        half = CAR_HITBOX / 2
        return pygame.Rect(round(x - half), round(y - half), CAR_HITBOX, CAR_HITBOX)

    @property
    def hitbox(self):
        return self.hitbox_at(self.pos.x, self.pos.y)

    def can_stand(self, x, y):
        rect = self.hitbox_at(x, y)
        return (rect.left >= 0 and rect.top >= 0
                and rect.right <= WORLD_W and rect.bottom <= WORLD_H
                and not any(rect.colliderect(wall) for wall in self.level.walls))

    def update(self, dt):
        if not self.alive:
            return
        self.teleport_cooldown = max(0.0, self.teleport_cooldown - dt)
        was_stunned = self.stun_left > 0
        self.stun_left = max(0.0, self.stun_left - dt)
        speed = self.move_speed
        self.boost_left = max(0.0, self.boost_left - dt)
        if was_stunned:
            return

        dx, dy = self.direction
        next_x = self.pos.x + dx * speed * dt
        next_y = self.pos.y + dy * speed * dt
        if self.can_stand(next_x, next_y):
            self.pos.update(next_x, next_y)

        if self.teleport_cooldown <= 0:
            for portal in self.level.portals:
                if self.hitbox.colliderect(portal.area):
                    if self.can_stand(*portal.exit_pos):
                        self.pos.update(*portal.exit_pos)
                        self.direction = portal.exit_dir
                        self.teleport_cooldown = PORTAL_COOLDOWN
                    break

    def draw(self, screen, font, layout):
        if not self.alive:
            return
        x, y = layout.to_screen(self.pos)
        dx, dy = self.direction
        horizontal = dx != 0
        w = max(10, round((34 if horizontal else 22) * layout.scale))
        h = max(10, round((22 if horizontal else 34) * layout.scale))
        rect = pygame.Rect(0, 0, w, h)
        rect.center = (x, y)

        if self.stun_left > 0:
            pygame.draw.rect(screen, STUN_GOLD, rect.inflate(10, 10), 3, border_radius=7)
        elif self.boost_left > 0:
            pygame.draw.rect(screen, BOOST_GREEN, rect.inflate(10, 10), 3, border_radius=7)

        pygame.draw.rect(screen, (20, 29, 42), rect.move(2, 3), border_radius=4)
        pygame.draw.rect(screen, self.color, rect, border_radius=4)
        pygame.draw.rect(screen, WHITE, rect, 2, border_radius=4)

        if dx == 1:
            pygame.draw.line(screen, WHITE, (rect.right - 6, y - 4), (rect.right - 6, y + 4), 3)
        elif dx == -1:
            pygame.draw.line(screen, WHITE, (rect.left + 6, y - 4), (rect.left + 6, y + 4), 3)
        elif dy == 1:
            pygame.draw.line(screen, WHITE, (x - 4, rect.bottom - 6), (x + 4, rect.bottom - 6), 3)
        else:
            pygame.draw.line(screen, WHITE, (x - 4, rect.top + 6), (x + 4, rect.top + 6), 3)

        label_image = font.render(self.label, True, (24, 32, 45))
        offset = max(25, round(37 * layout.scale))
        label_rect = label_image.get_rect(center=(x, y - offset if self.role == "police" else y + offset))
        label_bg = label_rect.inflate(12, 5)
        map_rect = pygame.Rect(layout.map_x, layout.map_y,
                               round(WORLD_W * layout.scale), round(WORLD_H * layout.scale))
        label_bg.clamp_ip(map_rect)
        label_rect.center = label_bg.center
        pygame.draw.rect(screen, WHITE, label_bg, border_radius=5)
        pygame.draw.rect(screen, self.color, label_bg, 2, border_radius=5)
        screen.blit(label_image, label_rect)


@dataclass
class Item:
    kind: str
    pos: tuple[int, int]
    remaining: float = ITEM_LIFETIME

    @property
    def hitbox(self):
        half = ITEM_HITBOX // 2
        return pygame.Rect(self.pos[0] - half, self.pos[1] - half,
                           ITEM_HITBOX, ITEM_HITBOX)

    def draw(self, screen, icon_font, layout):
        x, y = layout.to_screen(self.pos)
        k = max(0.7, min(1.45, layout.scale))
        if self.kind == "booster":
            bg = pygame.Rect(0, 0, round(56 * k), round(47 * k))
            bg.center = (x, y)
            pygame.draw.rect(screen, (223, 252, 231), bg, border_radius=8)
            pygame.draw.rect(screen, BOOST_GREEN, bg, 2, border_radius=8)
            pts = [
                (x, y - round(19 * k)), (x + round(13 * k), y - round(6 * k)),
                (x + round(6 * k), y - round(6 * k)), (x + round(6 * k), y + round(3 * k)),
                (x - round(6 * k), y + round(3 * k)), (x - round(6 * k), y - round(6 * k)),
                (x - round(13 * k), y - round(6 * k)),
            ]
            pygame.draw.polygon(screen, BOOST_GREEN, pts)
            word = icon_font.render("booster", True, (19, 111, 56))
            screen.blit(word, word.get_rect(center=(x, y + round(14 * k))))
        else:
            r = round(19 * k)
            pygame.draw.circle(screen, WHITE, (x, y), r)
            pygame.draw.circle(screen, (16, 19, 23), (x, y), r, max(2, round(4 * k)))
            pygame.draw.line(screen, (16, 19, 23), (x, y), (x, y - round(11 * k)), 3)
            pygame.draw.line(screen, (16, 19, 23), (x, y),
                             (x + round(9 * k), y + round(5 * k)), 3)
            pygame.draw.circle(screen, (16, 19, 23), (x, y), max(2, round(3 * k)))


def active_cars(police, thief1, thief2=None):
    cars = [police]
    if thief1 and thief1.alive:
        cars.append(thief1)
    if thief2 and thief2.alive:
        cars.append(thief2)
    return cars


def find_item_spawn(level, cars):
    margin = 29
    for _ in range(3000):
        x = random.randint(margin, WORLD_W - margin)
        y = random.randint(margin, WORLD_H - margin)
        area = pygame.Rect(x - margin, y - margin, margin * 2, margin * 2)
        if any(area.colliderect(wall) for wall in level.walls):
            continue
        if any(area.colliderect(portal.area) for portal in level.portals):
            continue
        if any(car.alive and car.pos.distance_to((x, y)) < 95 for car in cars):
            continue
        return (x, y)
    return None


def make_font(size, bold=False):
    for name in (
        "malgungothic", "nanumgothic", "nanumsquare", "notosanscjkkr",
        "notosanskr", "applegothic", "undotum", "baekmukdotum",
        "arial", "dejavusans",
    ):
        path = pygame.font.match_font(name, bold=bold)
        if path:
            return pygame.font.Font(path, size)
    return pygame.font.Font(None, size)


def build_map_surface(level, layout):
    surface = pygame.Surface((WORLD_W, WORLD_H)).convert()
    surface.fill(ROAD)

    for cy in (120, 333, 547):
        for cx in range(24, WORLD_W - 15, 54):
            pygame.draw.line(surface, ROAD_MARK, (cx, cy), (cx + 22, cy), 2)

    for wall in level.walls:
        pygame.draw.rect(surface, WALL, wall)
        pygame.draw.rect(surface, WALL_EDGE, wall, 2)

    portal_font = make_font(21, bold=True)
    abbreviations = {"red": "R", "blue": "B", "green": "G", "purple": "P", "orange": "O"}
    for portal in level.portals:
        color = PORTAL_COLORS[portal.name]
        translucent = pygame.Surface(portal.area.size, pygame.SRCALPHA)
        translucent.fill((*color, 65))
        surface.blit(translucent, portal.area.topleft)
        pygame.draw.rect(surface, color, portal.area, 4, border_radius=8)
        letter = portal_font.render(abbreviations[portal.name], True, color)
        surface.blit(letter, letter.get_rect(center=portal.area.center))

    pygame.draw.rect(surface, (43, 52, 67), surface.get_rect(), 5)
    return pygame.transform.smoothscale(
        surface, (round(WORLD_W * layout.scale), round(WORLD_H * layout.scale))
    )


def draw_text(surface, font, text, color, pos, anchor="topleft"):
    rendered = font.render(text, True, color)
    surface.blit(rendered, rendered.get_rect(**{anchor: pos}))


def find_nearby_spawn(level, anchor, occupied):
    probe = Car(anchor, (0, 1), WHITE, "", level, "thief")
    checks = [
        (0, 0), (55, 0), (-55, 0), (0, 55), (0, -55),
        (70, 70), (-70, 70), (70, -70), (-70, -70),
        (110, 0), (0, 110), (-110, 0), (0, -110),
    ]
    for ox, oy in checks:
        x, y = anchor[0] + ox, anchor[1] + oy
        if not probe.can_stand(x, y):
            continue
        rect = Car.hitbox_at(x, y)
        if any(rect.colliderect(other.hitbox) for other in occupied if other is not None):
            continue
        return (x, y)
    return anchor


def new_game(previous_map_index=None, mode="multi"):
    indexes = [i for i in range(len(MAPS)) if i != previous_map_index]
    index = random.choice(indexes)
    level = MAPS[index]
    police = Car(level.police_start, level.police_direction, POLICE_BLUE, "경찰", level, "police")
    thief1 = Car(level.thief_start, level.thief_direction, THIEF_RED,
                 "도둑" if mode != "duo" else "도둑1", level, "thief")
    thief2 = None
    if mode == "duo":
        t2_start = find_nearby_spawn(level, level.thief_start, [police, thief1])
        thief2 = Car(t2_start, level.thief_direction, THIEF_ORANGE, "도둑2", level, "thief")
    return index, level, police, thief1, thief2


GRID_STEP = 20
GRID_COLS = WORLD_W // GRID_STEP
GRID_ROWS = WORLD_H // GRID_STEP


class RoadNavigator:
    def __init__(self, level):
        self.level = level
        self.cells = []
        self.links = {}
        self.portals_at = {}
        for r in range(GRID_ROWS):
            for c in range(GRID_COLS):
                x, y = self.xy((c, r))
                box = Car.hitbox_at(x, y)
                if (box.left >= 0 and box.top >= 0 and
                        box.right <= WORLD_W and box.bottom <= WORLD_H and
                        not any(box.colliderect(w) for w in level.walls)):
                    self.cells.append((c, r))
        self.valid = set(self.cells)

        for c, r in self.cells:
            neighbors = [n for n in ((c+1, r), (c-1, r), (c, r+1), (c, r-1)) if n in self.valid]
            x, y = self.xy((c, r))
            box = Car.hitbox_at(x, y)
            for portal in level.portals:
                if box.colliderect(portal.area):
                    exit_node = self.nearest_node(portal.exit_pos)
                    if exit_node is not None and exit_node not in neighbors:
                        neighbors.append(exit_node)
                    self.portals_at[(c, r)] = portal
                    break
            self.links[(c, r)] = tuple(neighbors)

    @staticmethod
    def xy(node):
        return (node[0] * GRID_STEP + GRID_STEP / 2,
                node[1] * GRID_STEP + GRID_STEP / 2)

    def nearest_node(self, position):
        c = round((position[0] - GRID_STEP / 2) / GRID_STEP)
        r = round((position[1] - GRID_STEP / 2) / GRID_STEP)
        root = (c, r)
        if root in self.valid:
            return root
        for radius in range(1, 13):
            options = []
            for dc in range(-radius, radius+1):
                for dr in range(-radius, radius+1):
                    if max(abs(dc), abs(dr)) != radius:
                        continue
                    node = (c+dc, r+dr)
                    if node in self.valid:
                        px, py = self.xy(node)
                        options.append(((px-position[0])**2 + (py-position[1])**2, node))
            if options:
                return min(options)[1]
        return None

    def distances(self, start):
        distances = {start: 0} if start is not None else {}
        queue = deque([start]) if start is not None else deque()
        while queue:
            here = queue.popleft()
            d = distances[here] + 1
            for nxt in self.links[here]:
                if nxt not in distances:
                    distances[nxt] = d
                    queue.append(nxt)
        return distances

    def route(self, start, goal):
        if start is None or goal is None:
            return []
        parents = {start: None}
        queue = deque([start])
        while queue and goal not in parents:
            here = queue.popleft()
            for nxt in self.links[here]:
                if nxt not in parents:
                    parents[nxt] = here
                    queue.append(nxt)
        if goal not in parents:
            return []
        path = []
        node = goal
        while node is not None:
            path.append(node)
            node = parents[node]
        path.reverse()
        return path


class AIController:
    def __init__(self, level, role):
        self.nav = RoadNavigator(level)
        self.role = role
        self.path = []
        self.think_left = 0.0
        self.flee_goal = None
        self.flee_goal_left = 0.0

    def select_flee_goal(self, car, opponent):
        start = self.nav.nearest_node(car.pos)
        hunter = self.nav.nearest_node(opponent.pos)
        reachable = self.nav.distances(start)
        threat_dist = self.nav.distances(hunter)
        options = []
        for node, travel in reachable.items():
            if not (9 <= travel <= 48):
                continue
            away = threat_dist.get(node, 170)
            if away < 9:
                continue
            degree = len(self.nav.links[node])
            score = away * 1.05 - travel * 0.60 + random.random() * 6
            if degree <= 1:
                score -= 7
            options.append((score, node))
        if options:
            return max(options)[1]
        return max(reachable, key=reachable.get, default=start)

    def plan(self, car, opponent, item):
        start = self.nav.nearest_node(car.pos)
        target = self.nav.nearest_node(opponent.pos)
        if start is None:
            self.path = []
            return

        if self.role == "police":
            goal = target
            self.think_left = 0.42
        else:
            if self.flee_goal is None or self.flee_goal_left <= 0 or start == self.flee_goal:
                self.flee_goal = self.select_flee_goal(car, opponent)
                self.flee_goal_left = 2.7
            goal = self.flee_goal
            self.think_left = 0.60

        if item is not None and car.stun_left <= 0:
            item_goal = self.nav.nearest_node(item.pos)
            if item_goal is not None:
                item_path = self.nav.route(start, item_goal)
                steps = len(item_path) - 1
                travel_time = steps * GRID_STEP / max(1.0, car.move_speed)
                dist_to_enemy = car.pos.distance_to(opponent.pos)
                max_steps = 11 if self.role == "police" else 15
                if (item_path and 0 <= steps <= max_steps and
                        travel_time < item.remaining - 0.35 and
                        (self.role == "police" or dist_to_enemy > 200)):
                    goal = item_goal

        path = self.nav.route(start, goal)
        if not path and self.role == "thief":
            self.flee_goal_left = 0
            path = self.nav.route(start, self.select_flee_goal(car, opponent))
        self.path = path

    def move(self, car, opponent, item, dt):
        self.think_left -= dt
        self.flee_goal_left -= dt
        if self.think_left <= 0 or not self.path:
            self.plan(car, opponent, item)

        if car.stun_left > 0 or not self.path:
            car.update(dt)
            return

        remaining = dt
        for _ in range(12):
            if remaining <= 1e-6:
                return
            if not self.path:
                car.update(remaining)
                return

            node = self.path[0]
            tx, ty = self.nav.xy(node)
            delta_x = tx - car.pos.x
            delta_y = ty - car.pos.y

            if abs(delta_x) <= 0.15 and abs(delta_y) <= 0.15:
                car.pos.update(tx, ty)
                self.path.pop(0)
                continue

            if abs(delta_x) > 35 or abs(delta_y) > 35:
                portal = self.nav.portals_at.get(self.nav.nearest_node(car.pos))
                if portal is not None:
                    px, py = portal.area.center
                    dx, dy = px - car.pos.x, py - car.pos.y
                    if abs(dx) >= abs(dy):
                        car.direction = (1 if dx >= 0 else -1, 0)
                    else:
                        car.direction = (0, 1 if dy >= 0 else -1)
                old = car.pos.copy()
                car.update(remaining)
                if car.pos.distance_to(old) > car.move_speed * remaining + 35:
                    self.path = []
                    self.think_left = 0
                return

            if abs(delta_x) > 0.15:
                car.direction = (1 if delta_x > 0 else -1, 0)
                travel = abs(delta_x)
            else:
                car.direction = (0, 1 if delta_y > 0 else -1)
                travel = abs(delta_y)

            speed = car.move_speed
            step_dt = min(remaining, travel / max(1.0, speed))
            before = car.pos.copy()
            car.update(step_dt)
            remaining -= step_dt
            moved = car.pos.distance_to(before)

            if moved > speed * step_dt + 35 or (moved < 0.04 and step_dt > 0.0001):
                self.path = []
                self.think_left = 0
                if remaining > 0:
                    car.update(remaining)
                return

            if travel <= speed * step_dt + 0.15:
                if abs(delta_x) > 0.15:
                    car.pos.x = tx
                else:
                    car.pos.y = ty

        if remaining > 0:
            car.update(remaining)


def effect_text(car):
    if car is None:
        return ""
    if not car.alive:
        return "탈락"
    effects = []
    if car.boost_left > 0:
        effects.append(f"부스터 {car.boost_left:.1f}초")
    if car.stun_left > 0:
        effects.append(f"경직 {car.stun_left:.1f}초")
    return "  /  ".join(effects) if effects else "효과 없음"


def main():
    pygame.init()
    pygame.display.set_caption("경찰과 도둑 | 솔로 / 멀티 / 서바이벌 듀오")

    info = pygame.display.Info()
    desktop_size = (info.current_w or 1440, info.current_h or 720)
    screen = pygame.display.set_mode(desktop_size, pygame.FULLSCREEN)
    sw, sh = screen.get_size()
    layout = compute_layout(sw, sh)
    ui = layout.ui_scale
    clock = pygame.time.Clock()

    big_font = make_font(max(25, round(47 * ui)), bold=True)
    title_font = make_font(max(19, round(30 * ui)), bold=True)
    font = make_font(max(15, round(21 * ui)), bold=True)
    small_font = make_font(max(13, round(17 * ui)))
    tag_font = make_font(max(13, round(16 * ui)), bold=True)
    item_font = make_font(max(10, round(13 * max(0.7, min(1.45, layout.scale)))), bold=True)
    button_font = make_font(max(18, round(26 * ui)), bold=True)

    map_surfaces = [build_map_surface(level, layout) for level in MAPS]
    map_index, level, police, thief, thief2 = new_game(None, "multi")
    state = "menu"
    mode = None                # "solo", "multi", "duo"
    player_role = None         # solo only
    ai = None                  # solo: 상대 AI, duo: AI 경찰
    time_left = ROUND_TIME
    winner = ""
    item = None
    spawn_elapsed = 0.0
    chase_notice_left = 0.0
    buttons = []

    police_keys = {
        pygame.K_w: (0, -1), pygame.K_a: (-1, 0),
        pygame.K_s: (0, 1), pygame.K_d: (1, 0),
    }
    thief_keys = {
        pygame.K_UP: (0, -1), pygame.K_LEFT: (-1, 0),
        pygame.K_DOWN: (0, 1), pygame.K_RIGHT: (1, 0),
    }

    def reset_round():
        nonlocal map_index, level, police, thief, thief2, ai, state
        nonlocal time_left, winner, item, spawn_elapsed, chase_notice_left
        map_index, level, police, thief, thief2 = new_game(map_index, mode or "multi")
        ai = None
        if mode == "solo":
            ai_role = "thief" if player_role == "police" else "police"
            ai = AIController(level, ai_role)
        elif mode == "duo":
            ai = AIController(level, "police")
        time_left = ROUND_TIME
        winner = ""
        item = None
        spawn_elapsed = 0.0
        chase_notice_left = 0.0
        state = "ready"

    def activate(action):
        nonlocal state, mode, player_role
        if action == "solo":
            mode = "solo"
            state = "choose_role"
        elif action == "multi":
            mode = "multi"
            player_role = None
            reset_round()
        elif action == "duo":
            mode = "duo"
            player_role = None
            reset_round()
        elif action in ("police", "thief"):
            mode = "solo"
            player_role = action
            reset_round()
        elif action == "start" and state == "ready":
            state = "running"
        elif action == "again" and state == "finished":
            reset_round()
            state = "running"
        elif action == "back":
            if state == "choose_role":
                mode = None
            state = "menu"
        elif action == "menu":
            mode = None
            player_role = None
            state = "menu"

    def draw_button(rect, label, action, accent, subtitle=None):
        hovered = rect.collidepoint(pygame.mouse.get_pos())
        fill = tuple(min(255, c + (24 if hovered else 0)) for c in accent)
        if hovered:
            pygame.draw.rect(screen, fill, rect.move(0, 4), border_radius=13)
        pygame.draw.rect(screen, fill, rect, border_radius=13)
        pygame.draw.rect(screen, WHITE, rect, 2, border_radius=13)
        if subtitle:
            draw_text(screen, button_font, label, WHITE,
                      (rect.centerx, rect.y + round(9 * ui)), "midtop")
            draw_text(screen, small_font, subtitle, (238, 241, 248),
                      (rect.centerx, rect.bottom - round(22 * ui)), "midtop")
        else:
            draw_text(screen, button_font, label, WHITE, rect.center, "center")
        buttons.append((rect, action))

    while True:
        dt = min(clock.tick(FPS) / 1000.0, 0.05)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    return
                if event.key == pygame.K_m and state not in ("menu", "choose_role"):
                    activate("menu")
                elif event.key == pygame.K_r and state in ("ready", "running", "finished"):
                    reset_round()
                elif event.key == pygame.K_SPACE and state == "ready":
                    activate("start")
                elif event.key == pygame.K_1 and state == "menu":
                    activate("solo")
                elif event.key == pygame.K_2 and state == "menu":
                    activate("multi")
                elif event.key == pygame.K_3 and state == "menu":
                    activate("duo")
                elif event.key == pygame.K_1 and state == "choose_role":
                    activate("police")
                elif event.key == pygame.K_2 and state == "choose_role":
                    activate("thief")
                elif state == "running":
                    if mode == "solo":
                        if (event.key in police_keys and police.stun_left <= 0 and player_role == "police"):
                            police.direction = police_keys[event.key]
                        elif (event.key in thief_keys and thief.stun_left <= 0 and player_role == "thief"):
                            thief.direction = thief_keys[event.key]
                    elif mode == "multi":
                        if event.key in police_keys and police.stun_left <= 0:
                            police.direction = police_keys[event.key]
                        elif event.key in thief_keys and thief.stun_left <= 0:
                            thief.direction = thief_keys[event.key]
                    elif mode == "duo":
                        if thief.alive and event.key in police_keys and thief.stun_left <= 0:
                            thief.direction = police_keys[event.key]
                        elif thief2 and thief2.alive and event.key in thief_keys and thief2.stun_left <= 0:
                            thief2.direction = thief_keys[event.key]
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for rect, action in buttons:
                    if rect.collidepoint(event.pos):
                        activate(action)
                        break

        if state == "running":
            previous_time = time_left
            time_left = max(0.0, time_left - dt)
            if previous_time > CHASE_TRIGGER_TIME >= time_left:
                chase_notice_left = CHASE_NOTICE_DURATION
            chase_notice_left = max(0.0, chase_notice_left - dt)
            police.chase_active = 0 < time_left <= CHASE_TRIGGER_TIME
            if time_left > 0:
                if mode == "solo" and ai is not None:
                    if player_role == "police":
                        police.update(dt)
                        ai.move(thief, police, item, dt)
                    else:
                        ai.move(police, thief, item, dt)
                        thief.update(dt)
                elif mode == "duo" and ai is not None:
                    targets = [c for c in (thief, thief2) if c is not None and c.alive]
                    if targets:
                        target = min(targets, key=lambda c: police.pos.distance_to(c.pos))
                        ai.move(police, target, item, dt)
                    else:
                        police.update(dt)
                    thief.update(dt)
                    if thief2 is not None:
                        thief2.update(dt)
                else:
                    police.update(dt)
                    thief.update(dt)

                if mode == "duo":
                    for t in (thief, thief2):
                        if t is not None and t.alive and police.hitbox.colliderect(t.hitbox):
                            t.alive = False
                            t.boost_left = 0.0
                            t.stun_left = 0.0
                    if not thief.alive and (thief2 is None or not thief2.alive):
                        state, winner = "finished", "경찰 승리!"
                else:
                    if police.hitbox.colliderect(thief.hitbox):
                        state, winner = "finished", "경찰 승리!"

                if state == "running":
                    if item is not None:
                        item.remaining -= dt
                        if item.remaining <= 0:
                            item = None

                    spawn_elapsed += dt
                    if spawn_elapsed >= ITEM_SPAWN_INTERVAL:
                        spawn_elapsed -= ITEM_SPAWN_INTERVAL
                        place = find_item_spawn(level, active_cars(police, thief, thief2))
                        if place is not None:
                            item = Item(random.choice(("booster", "stun")), place)

                    if item is not None:
                        cars_here = [car for car in active_cars(police, thief, thief2)
                                     if car.hitbox.colliderect(item.hitbox)]
                        if cars_here:
                            collector = min(cars_here, key=lambda car: car.pos.distance_to(item.pos))
                            if item.kind == "booster":
                                collector.boost_left = BOOST_DURATION
                            else:
                                if collector.role == "police":
                                    if mode == "duo":
                                        targets = [c for c in (thief, thief2) if c is not None and c.alive]
                                        if targets:
                                            min(targets, key=lambda c: collector.pos.distance_to(c.pos)).stun_left = STUN_DURATION
                                    else:
                                        thief.stun_left = STUN_DURATION
                                else:
                                    police.stun_left = STUN_DURATION
                            item = None

            if state == "running" and time_left <= 0:
                if mode == "duo":
                    winner = "도둑 팀 승리!" if (thief.alive or (thief2 is not None and thief2.alive)) else "경찰 승리!"
                else:
                    winner = "도둑 승리!"
                state = "finished"

        # ───────────────── 지도 및 상태 표시 ─────────────────
        screen.fill(BG)
        pygame.draw.rect(screen, PANEL, (0, 0, sw, layout.header_h))
        left = layout.map_x
        right = sw - layout.map_x
        pad = max(8, round(18 * ui))
        heading = "경찰과 도둑"
        if mode == "solo" and state in ("ready", "running", "finished"):
            heading += "   ·   SOLO"
        elif mode == "multi" and state in ("ready", "running", "finished"):
            heading += "   ·   MULTI"
        elif mode == "duo" and state in ("ready", "running", "finished"):
            heading += "   ·   SURVIVAL DUO"
        draw_text(screen, title_font, heading, WHITE, (left, pad))
        draw_text(screen, small_font,
                  f"{level.name} ({map_index+1}/{len(MAPS)})  |  10초마다 아이템  |  부스터 +30%(5초)  |  경직(2.5초)",
                  MUTED, (left, max(35, round(60 * ui))))
        timer_color = (255, 104, 113) if police.chase_active and state == "running" else WHITE
        draw_text(screen, big_font, f"{math.ceil(time_left):02d}s", timer_color,
                  (right, max(5, round(12 * ui))), "topright")
        if state == "running":
            if item is not None:
                info_text = f"아이템 사라짐: {item.remaining:.1f}초"
            else:
                info_text = f"다음 아이템: {max(0, ITEM_SPAWN_INTERVAL-spawn_elapsed):.1f}초"
            draw_text(screen, small_font, info_text, MUTED,
                      (right, max(35, round(74 * ui))), "topright")

        screen.blit(map_surfaces[map_index], (layout.map_x, layout.map_y))
        if state == "running" and police.chase_active:
            banner_font = font if chase_notice_left > 0 else small_font
            notice = ("추격 이벤트!  경찰 속도 +10%" if chase_notice_left > 0 else "추격 중  ·  경찰 +10%")
            label_surface = banner_font.render(notice, True, WHITE)
            banner_w = label_surface.get_width() + round(32 * ui)
            banner_h = label_surface.get_height() + round(16 * ui)
            banner = pygame.Rect(0, 0, banner_w, banner_h)
            banner.midtop = (sw // 2, layout.map_y + max(8, round(12 * ui)))
            pygame.draw.rect(screen, (117, 35, 49), banner, border_radius=10)
            pygame.draw.rect(screen, (255, 115, 120), banner, 2, border_radius=10)
            screen.blit(label_surface, label_surface.get_rect(center=banner.center))

        if item is not None:
            item.draw(screen, item_font, layout)
        police.draw(screen, tag_font, layout)
        thief.draw(screen, tag_font, layout)
        if thief2 is not None:
            thief2.draw(screen, tag_font, layout)

        footer_y = sh - layout.footer_h
        pygame.draw.rect(screen, PANEL, (0, footer_y, sw, layout.footer_h))
        pygame.draw.line(screen, (59, 72, 91), (0, footer_y), (sw, footer_y), 1)
        columns = [left, left + round(330 * ui), left + round(660 * ui)]

        if mode == "duo":
            draw_text(screen, font, "경찰 (AI)", POLICE_BLUE,
                      (columns[0], footer_y + max(6, round(10 * ui))))
            draw_text(screen, small_font, "자동 조작",
                      WHITE, (columns[0] + round(120 * ui), footer_y + max(10, round(16 * ui))))
            p_status = effect_text(police)
            if state == "running" and police.chase_active:
                p_status += "  /  추격 +10%" if p_status != "효과 없음" else "추격 +10%"
            p_color = STUN_GOLD if police.stun_left > 0 else BOOST_GREEN if police.boost_left > 0 else (255, 140, 145) if police.chase_active and state == "running" else MUTED
            draw_text(screen, small_font, p_status, p_color,
                      (columns[0], footer_y + max(32, round(42 * ui))))

            draw_text(screen, font, "도둑1", THIEF_RED,
                      (columns[1], footer_y + max(6, round(10 * ui))))
            draw_text(screen, small_font, "W A S D",
                      WHITE, (columns[1] + round(90 * ui), footer_y + max(10, round(16 * ui))))
            draw_text(screen, small_font, effect_text(thief),
                      STUN_GOLD if thief.stun_left > 0 else BOOST_GREEN if thief.boost_left > 0 else MUTED,
                      (columns[1], footer_y + max(32, round(42 * ui))))

            draw_text(screen, font, "도둑2", THIEF_ORANGE,
                      (columns[2], footer_y + max(6, round(10 * ui))))
            draw_text(screen, small_font, "방향키",
                      WHITE, (columns[2] + round(90 * ui), footer_y + max(10, round(16 * ui))))
            draw_text(screen, small_font, effect_text(thief2),
                      STUN_GOLD if thief2 and thief2.stun_left > 0 else BOOST_GREEN if thief2 and thief2.boost_left > 0 else MUTED,
                      (columns[2], footer_y + max(32, round(42 * ui))))
        else:
            x_police = left
            x_thief = left + round(430 * ui)
            p_user = mode == "solo" and player_role == "police"
            t_user = mode == "solo" and player_role == "thief"
            p_tag = "(나)" if p_user else "(AI)" if mode == "solo" else ""
            t_tag = "(나)" if t_user else "(AI)" if mode == "solo" else ""
            draw_text(screen, font, "경찰 " + p_tag, POLICE_BLUE,
                      (x_police, footer_y + max(6, round(10 * ui))))
            draw_text(screen, small_font, "W A S D" if mode != "solo" or p_user else "자동 조작",
                      WHITE, (x_police + round(120 * ui), footer_y + max(10, round(16 * ui))))
            police_status = effect_text(police)
            if state == "running" and police.chase_active:
                police_status += "  /  추격 +10%" if police_status != "효과 없음" else "추격 +10%"
            draw_text(screen, small_font, police_status,
                      STUN_GOLD if police.stun_left > 0 else BOOST_GREEN if police.boost_left > 0 else (255, 140, 145) if police.chase_active and state == "running" else MUTED,
                      (x_police, footer_y + max(32, round(42 * ui))))

            draw_text(screen, font, "도둑 " + t_tag, THIEF_RED,
                      (x_thief, footer_y + max(6, round(10 * ui))))
            draw_text(screen, small_font, "방향키" if mode != "solo" or t_user else "자동 조작",
                      WHITE, (x_thief + round(120 * ui), footer_y + max(10, round(16 * ui))))
            draw_text(screen, small_font, effect_text(thief),
                      STUN_GOLD if thief.stun_left > 0 else BOOST_GREEN if thief.boost_left > 0 else MUTED,
                      (x_thief, footer_y + max(32, round(42 * ui))))

        draw_text(screen, small_font, "SPACE 시작   R 새 맵   M 모드 선택   ESC 종료",
                  MUTED, (right, footer_y + max(18, round(22 * ui))), "topright")

        buttons = []
        if state in ("menu", "choose_role", "ready", "finished"):
            dim = pygame.Surface((sw, sh), pygame.SRCALPHA)
            dim.fill((8, 13, 24, 188))
            screen.blit(dim, (0, 0))
            panel_w = min(sw - 20, round(790 * ui))
            panel_h = min(sh - 20, round(500 * ui))
            panel = pygame.Rect(0, 0, panel_w, panel_h)
            panel.center = (sw // 2, sh // 2)
            pygame.draw.rect(screen, PANEL, panel, border_radius=20)
            pygame.draw.rect(screen, (95, 116, 149), panel, 2, border_radius=20)
            cx = panel.centerx
            gap = round(15 * ui)
            bw = round(250 * ui)
            bh = round(78 * ui)
            btn_y = panel.y + round(210 * ui)
            start_x = cx - bw - gap // 2
            end_x = cx + gap // 2

            if state == "menu":
                draw_text(screen, big_font, "경찰과 도둑", WHITE,
                          (cx, panel.top + round(42 * ui)), "midtop")
                draw_text(screen, font, "플레이할 모드를 선택하세요", MUTED,
                          (cx, panel.top + round(118 * ui)), "midtop")
                row1_y = btn_y
                row2_y = btn_y + bh + round(18 * ui)
                trio_x = cx - bw // 2
                draw_button(pygame.Rect(start_x, row1_y, bw, bh),
                            "솔로모드", "solo", (30, 113, 178), "AI와 1대1 대결 · 숫자 1")
                draw_button(pygame.Rect(end_x, row1_y, bw, bh),
                            "멀티모드", "multi", (152, 67, 84), "경찰 vs 도둑 · 숫자 2")
                draw_button(pygame.Rect(trio_x, row2_y, bw, bh),
                            "서바이벌 듀오", "duo", (198, 117, 27), "도둑 2명 vs AI 경찰 · 숫자 3")
                draw_text(screen, small_font,
                          f"맵 {len(MAPS)}종 랜덤  ·  80초 제한  ·  추격 이벤트/아이템/텔레포트 지원",
                          MUTED, (cx, panel.bottom - round(48 * ui)), "midtop")
            elif state == "choose_role":
                draw_text(screen, big_font, "솔로모드", WHITE,
                          (cx, panel.top + round(44 * ui)), "midtop")
                draw_text(screen, font, "어느 역할을 플레이할까요?", MUTED,
                          (cx, panel.top + round(123 * ui)), "midtop")
                draw_button(pygame.Rect(start_x, btn_y, bw, bh),
                            "경찰 플레이", "police", (30, 113, 178), "WASD 조작 · AI 도둑")
                draw_button(pygame.Rect(end_x, btn_y, bw, bh),
                            "도둑 플레이", "thief", (152, 67, 84), "방향키 조작 · AI 경찰")
                draw_text(screen, small_font, "1: 경찰  ·  2: 도둑  ·  아래 버튼으로 뒤로 가기",
                          MUTED, (cx, panel.bottom - round(58 * ui)), "midtop")
                back = pygame.Rect(0, 0, round(115 * ui), round(38 * ui))
                back.midbottom = (cx, panel.bottom - round(10 * ui))
                pygame.draw.rect(screen, (58, 69, 90), back, border_radius=9)
                draw_text(screen, small_font, "뒤로", WHITE, back.center, "center")
                buttons.append((back, "back"))
            elif state == "ready":
                draw_text(screen, big_font, "출발 준비!", WHITE,
                          (cx, panel.top + round(38 * ui)), "midtop")
                display_mode = "솔로모드" if mode == "solo" else "멀티모드" if mode == "multi" else "서바이벌 듀오"
                if mode == "solo":
                    match_label = ("내 역할: 경찰  |  AI: 도둑" if player_role == "police"
                                   else "내 역할: 도둑  |  AI: 경찰")
                elif mode == "multi":
                    match_label = "경찰: WASD  |  도둑: 방향키"
                else:
                    match_label = "도둑1: WASD  |  도둑2: 방향키  |  AI 경찰 추격"
                draw_text(screen, font, f"{display_mode}  ·  {level.name}", WHITE,
                          (cx, panel.top + round(114 * ui)), "midtop")
                draw_text(screen, small_font, match_label, MUTED,
                          (cx, panel.top + round(155 * ui)), "midtop")
                draw_button(pygame.Rect(start_x, btn_y, bw, bh),
                            "게임 시작", "start", (31, 134, 89), "클릭 또는 SPACE")
                draw_button(pygame.Rect(end_x, btn_y, bw, bh),
                            "모드 선택", "menu", (67, 83, 108), "시작 화면으로")
                draw_text(screen, small_font, "R: 랜덤 맵 변경  ·  ESC: 게임 종료",
                          MUTED, (cx, panel.bottom - round(55 * ui)), "midtop")
            else:
                color = POLICE_BLUE if winner.startswith("경찰") else THIEF_RED
                draw_text(screen, big_font, winner, color,
                          (cx, panel.top + round(44 * ui)), "midtop")
                if mode == "solo":
                    human_won = ((player_role == "police" and winner.startswith("경찰"))
                                 or (player_role == "thief" and winner.startswith("도둑")))
                    info_text = "플레이어 승리!" if human_won else "AI 승리!"
                elif mode == "multi":
                    info_text = "2인 대결 종료"
                else:
                    info_text = "도둑 팀은 한 명만 살아남아도 승리합니다"
                draw_text(screen, font, info_text, WHITE,
                          (cx, panel.top + round(133 * ui)), "midtop")
                draw_button(pygame.Rect(start_x, btn_y, bw, bh),
                            "다시 하기", "again", (31, 134, 89), "새 랜덤 맵으로 시작")
                draw_button(pygame.Rect(end_x, btn_y, bw, bh),
                            "모드 선택", "menu", (67, 83, 108), "다른 모드로 변경")
                draw_text(screen, small_font, "R: 새 맵 준비  ·  M: 모드 선택  ·  ESC: 종료",
                          MUTED, (cx, panel.bottom - round(55 * ui)), "midtop")

        pygame.display.flip()


if __name__ == "__main__":
    main()
