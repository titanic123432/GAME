PULSE 4K MOBILE — Android 빌드용 소스 프로젝트

현재 파일은 APK 자체가 아니라 APK를 만들 수 있도록 구성한 Android Studio 프로젝트입니다.
기존 PC 버전과 독립적이며, 아홉 곡의 음원, 미리듣기, 일러스트, 27개 채보가 포함됩니다.
Android 7.0 이상(minSdk 24), 세로 화면, 멀티터치, 롱노트 부분 점수, 일시정지, 결과 화면.
최초 미리듣기는 곡 목록 또는 미리듣기 버튼을 터치해야 시작합니다.

Windows에서 APK 만들기:
1. 공식 Android Studio 설치: https://developer.android.com/studio
2. Android Studio의 SDK Manager에서 Android SDK Platform 35와 Android SDK Build-Tools를 설치하고 라이선스에 동의합니다.
3. 이 ZIP 전체를 압축 해제하고 Build_APK.bat를 실행합니다.
   첫 빌드는 Gradle과 Android Gradle Plugin을 공식 저장소에서 내려받으므로 인터넷이 필요합니다.
   SDK/JDK 경로가 기본 설치 위치와 다르면 ANDROID_HOME/JAVA_HOME 환경변수를 지정합니다.
4. 성공하면 폴더에 PULSE4K_Mobile.apk가 생성됩니다. 해당 APK를 휴대폰으로 옮겨 설치합니다.
   직접 설치가 제한되는 기기에서는 보호자 또는 기기 관리자의 도움을 받으세요.

또는 Android Studio에서 이 폴더를 열고 Gradle 8.9를 선택해 동기화한 뒤 Build > Generate APKs를 사용해도 됩니다.
앱은 디버그 서명 APK로 빌드되며 Play 스토어 배포용 서명과는 다릅니다.

조작: 곡 목록을 스크롤해 선택, 난이도 선택 후 PLAY. 아래 네 레인을 터치합니다.
롱노트는 놓쳐도 끝까지 유지되며 실제 누른 시간만 점수에 반영합니다.
싱크(양수일수록 노트가 일찍 도착) 및 노트 낙하 시간을 로비에서 조절할 수 있습니다.
음원 및 채보는 원래 사용자 제공 파일을 그대로 사용했습니다.
현재 작업 환경에 Android SDK가 없어 APK 빌드, 실제 안드로이드 기기 동작 및 오디오 지연 테스트는 하지 못했습니다.


1.1: 홈 화면 앱 이름을 워로봇 리듬게임으로 변경, 새 런처 아이콘 적용. 앱 패키지 ID 및 게임 데이터 유지. GitHub Actions 빌드 후 APK 파일 이름만 변경해도 설치 이름에는 영향이 없습니다.

1.2: Martian Robotic Games 추가 (영상 음원 추출, 자동 분석 채보, 커버/배경/미리듣기). 기존 앱 ID 및 아이콘 유지. 고정 서명 및 곡 가져오기 기능은 아직 적용하지 않았습니다.

1.3: 곡 순서 변경 및 WR Mecha Rider SWORD 이름 적용. 롱노트 종료 시 손을 떼지 않아도 자동 판정. 약 0.1초 간격 콤보, 실제 누른 시간 비례 점수, 콤보 아래 HOLD 추가 점수 표시. 놓친 구간에서 콤보가 끊기지만 재입력 가능. 시작 45ms 이내 입력은 PERFECT 타이밍으로 인정. 최대 점수 1,000,000점 유지.


V1.4: World Iron Cup 추가 (135 BPM 추정), 응원 박자형 채보. 기존 5곡 채보 및 V1.3 롱노트 엔진 유지. GitHub 웹 업로드 제한에 맞추기 위해 Main Mixed 160kbps, Tiger 192kbps로 재인코딩.
World Iron Cup 재생 음원 112kbps MP3.

V1.5: Van-di Auction House 추가 (130 BPM 추정). 기존 6곡 채보와 게임 엔진 유지. 신규 음원 112kbps, WR REVOLVE 128kbps, Tiger 160kbps로 인코딩.

V1.6: Lunar, Christmas 추가. 기존 7곡 채보 및 엔진 유지. GitHub 웹 업로드 용량에 맞추기 위해 Main Mixed/Tiger 및 신규곡 MP3 112kbps, Sword MP3 160kbps, 기존 미리듣기 용량 조정. Van-di 미리듣기 재생 구간 복원.

V1.7: Icarus Cyber Invasion added. 10 songs / 30 charts. Existing preview audio compressed to save space.
