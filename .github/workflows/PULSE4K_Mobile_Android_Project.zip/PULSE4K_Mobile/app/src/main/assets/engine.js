class Engine {
 constructor(notes){this.notes=notes.map(([t,l,d])=>({t,l,d,end:t+d,covered:0,done:false}));this.lanes=[0,1,2,3].map(l=>this.notes.filter(n=>n.l===l).sort((a,b)=>a.t-b.t));this.idx=[0,0,0,0];this.held=[false,false,false,false];this.prev=-3;this.weight=0;this.combo=0;this.max=0;this.count={PERFECT:0,GREAT:0,GOOD:0,PARTIAL:0,MISS:0};this.last='';this.judgeTime=-100;this.holdLength=this.notes.reduce((s,n)=>s+n.d,0);this.covered=0;}
 mark(n,k,p,now){n.done=true;this.idx[n.l]++;this.weight+=p;this.count[k]++;if(k==='MISS'||k==='PARTIAL')this.combo=0;else this.max=Math.max(this.max,++this.combo);this.last=k;this.judgeTime=now;}
 advance(now){now=Math.max(this.prev,now);for(let l=0;l<4;l++){let n;while((n=this.lanes[l][this.idx[l]])){if(n.d){if(now<n.t)break;if(this.held[l])n.covered=Math.min(n.d,n.covered+Math.max(0,Math.min(now,n.end)-Math.max(this.prev,n.t)));if(now<n.end)break;let f=n.covered/n.d;this.covered+=n.covered;this.mark(n,f>1-1e-6?'PERFECT':f>1e-6?'PARTIAL':'MISS',f>1-1e-6?1:f,now);}else if(now>n.t+.155){this.mark(n,'MISS',0,now);}else break;}}this.prev=now;}
 down(l,now){this.advance(now);if(this.held[l])return;this.held[l]=true;const n=this.lanes[l][this.idx[l]];if(!n||n.d)return;let e=Math.abs(now-n.t);if(e<=.155)this.mark(n,e<=.045?'PERFECT':e<=.085?'GREAT':'GOOD',e<=.045?1:e<=.085?.75:.4,now);}
 up(l,now){this.advance(now);this.held[l]=false;}
 get score(){let p=this.weight;for(let l=0;l<4;l++){const n=this.lanes[l][this.idx[l]];if(n?.d)p+=n.covered/n.d;}return Math.round(1e6*p/this.notes.length);}
 get accuracy(){const n=Object.values(this.count).reduce((a,b)=>a+b,0);return n?100*this.weight/n:100;}
}
if(typeof module!=='undefined')module.exports=Engine;
