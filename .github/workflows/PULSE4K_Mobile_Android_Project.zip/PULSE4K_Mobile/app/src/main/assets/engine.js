// Hold notes award proportional score and combo ticks; no release judgement.
const HOLD_TICK = .10, EPS = 1e-7, HEAD_GRACE = .045;
class Engine {
 constructor(notes){
  this.notes=notes.map(([t,l,d])=>({t,l,d,end:t+d,covered:0,done:false,tick:0,tickCovered:0,ticks:d?Math.max(1,Math.ceil(d/HOLD_TICK-EPS)):0,started:false}));
  this.lanes=[0,1,2,3].map(l=>this.notes.filter(n=>n.l===l).sort((a,b)=>a.t-b.t));
  this.idx=[0,0,0,0];this.held=[false,false,false,false];this.prev=-3;this.weight=0;this.combo=0;this.max=0;
  this.count={PERFECT:0,GREAT:0,GOOD:0,PARTIAL:0,MISS:0};this.last='';this.judgeTime=-100;this.holdLength=this.notes.reduce((s,n)=>s+n.d,0);this.covered=0;this.recentHolds=[];
 }
 comboHit(){this.max=Math.max(this.max,++this.combo);}
 judge(k,now){this.last=k;this.judgeTime=now;}
 mark(n,k,p,now,events=null){
  n.done=true;this.idx[n.l]++;this.weight+=p;this.count[k]++;
  if(n.d){this.covered+=n.covered;this.recentHolds.push(n);}
  const event={time:now,kind:'mark',k,hold:!!n.d};
  if(events)events.push(event);else this.apply(event);
 }
 apply(e){
  if(e.kind==='tick'){if(e.ok)this.comboHit();else this.combo=0;return;}
  // Hold combo was already counted by ticks, including gaps; don't count/reset twice.
  if(!e.hold){if(e.k==='MISS'||e.k==='PARTIAL')this.combo=0;else this.comboHit();}
  this.judge(e.k,e.time);
 }
 advance(now){
  now=Math.max(this.prev,now);const events=[];
  for(let l=0;l<4;l++){
   let n;while((n=this.lanes[l][this.idx[l]])){
    if(n.d){
     if(now<n.t)break;
     while(n.tick<n.ticks){
      const a=n.t+n.d*n.tick/n.ticks,b=n.t+n.d*(n.tick+1)/n.ticks;
      const amount=this.held[l]?Math.max(0,Math.min(now,b)-Math.max(this.prev,a)):0;
      if(amount>0){n.started=true;n.tickCovered+=amount;n.covered=Math.min(n.d,n.covered+amount);}
      if(now+EPS<b)break;
      events.push({time:b,kind:'tick',ok:n.tickCovered>=b-a-EPS});n.tick++;n.tickCovered=0;
     }
     if(now+EPS<n.end)break;
     const f=Math.min(1,n.covered/n.d),k=f>=1-EPS?'PERFECT':f>EPS?'PARTIAL':'MISS';
     this.mark(n,k,k==='PERFECT'?1:f,n.end,events);
    }else if(now>n.t+.155){this.mark(n,'MISS',0,n.t+.155,events);}else break;
   }
  }
  events.sort((a,b)=>a.time-b.time||(a.kind==='tick'?-1:1)-(b.kind==='tick'?-1:1));
  for(const e of events)this.apply(e);
  this.prev=now;this.recentHolds=this.recentHolds.filter(n=>now-n.end<=.85);
 }
 down(l,now){
  this.advance(now);now=this.prev;if(this.held[l])return;this.held[l]=true;
  const n=this.lanes[l][this.idx[l]];if(!n)return;
  if(n.d){
   // Same 45 ms timing grace as a PERFECT tap, at the head only.
   const delay=now-n.t;
   if(!n.started&&n.tick===0&&delay>=0&&delay<=HEAD_GRACE+EPS){n.started=true;n.covered=delay;n.tickCovered=delay;}
   return;
  }
  let e=Math.abs(now-n.t);if(e<=.155+EPS)this.mark(n,e<=.045+EPS?'PERFECT':e<=.085+EPS?'GREAT':'GOOD',e<=.045+EPS?1:e<=.085+EPS?.75:.4,now);
 }
 up(l,now){this.advance(now);this.held[l]=false;}
 get activeHolds(){return this.lanes.map((a,l)=>a[this.idx[l]]).filter(n=>n?.d&&this.prev>=n.t&&this.prev<n.end);}
 get holdBonus(){const holds=[...this.activeHolds,...this.recentHolds];return {visible:holds.length>0,points:Math.round(1e6*holds.reduce((s,n)=>s+n.covered/n.d,0)/this.notes.length)};}
 get score(){let p=this.weight;for(const n of this.activeHolds)p+=n.covered/n.d;return Math.round(1e6*p/this.notes.length);}
 get accuracy(){let p=this.weight,n=Object.values(this.count).reduce((a,b)=>a+b,0);for(const h of this.activeHolds){const elapsed=Math.max(0,Math.min(h.d,this.prev-h.t));p+=h.covered/h.d;n+=elapsed/h.d;}return n?Math.min(100,100*p/n):100;}
}
if(typeof module!=='undefined')module.exports=Engine;
