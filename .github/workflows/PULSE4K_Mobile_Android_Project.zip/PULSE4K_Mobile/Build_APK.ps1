$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not $env:JAVA_HOME) {
  $jbr = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
  if (Test-Path "$jbr\bin\java.exe") { $env:JAVA_HOME = $jbr }
}
if ($env:JAVA_HOME) { $env:Path = "$env:JAVA_HOME\bin;$env:Path" }
if (-not (Get-Command java -ErrorAction SilentlyContinue)) { throw 'Install Android Studio (JDK 17 or 21) first.' }
if (-not $env:ANDROID_HOME) { if ($env:ANDROID_SDK_ROOT) { $env:ANDROID_HOME=$env:ANDROID_SDK_ROOT } else { $env:ANDROID_HOME=Join-Path $env:LOCALAPPDATA 'Android\Sdk' } }
if (-not (Test-Path "$env:ANDROID_HOME\platforms\android-35\android.jar")) { throw 'Open Android Studio > SDK Manager and install Android SDK Platform 35 first.' }
$gdir=Join-Path $env:LOCALAPPDATA 'Pulse4KBuild\gradle-8.9'
if (-not (Test-Path "$gdir\bin\gradle.bat")) {
  $parent=Split-Path $gdir; New-Item -ItemType Directory -Force $parent | Out-Null
  $zip=Join-Path $parent 'gradle-8.9-bin.zip'
  Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile $zip
  Expand-Archive -Path $zip -DestinationPath $parent -Force
}
& "$gdir\bin\gradle.bat" --no-daemon assembleDebug
if ($LASTEXITCODE -ne 0) { throw 'APK build failed. See Gradle error above.' }
Copy-Item 'app\build\outputs\apk\debug\app-debug.apk' 'PULSE4K_Mobile.apk' -Force
Write-Host 'Done: PULSE4K_Mobile.apk'
