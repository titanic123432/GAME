"""경찰과 도둑: 솔로 AI 대전과 2인용 모드를 지원하는 Pygame 추격전.

설치: pip install pygame
실행: python police_chase.py

경찰: WASD / 도둑: 방향키 / 화면 버튼으로 모드 선택 / SPACE: 시작
R: 새 맵 / M: 모드 선택 / ESC: 전체 화면 게임 종료
"""

import math
import random
from collections import deque
from dataclasses import dataclass

import pygame

# ────────────────── 밸런스 설정 ──────────────────
WORLD_W, WORLD_H = 1760, 680
FPS = 60
ROUND_TIME = 80.0                 # 제한시간: 80초
CAR_SPEED = 205.0                 # 초당 이동 거리 (맵 좌표 기준)
CAR_HITBOX = 32
PORTAL_COOLDOWN = 1.0

ITEM_SPAWN_INTERVAL = 10.0        # 아이템 생성 간격
ITEM_LIFETIME = 5.0               # 생성 후 5초 뒤 사라짐
ITEM_HITBOX = 30
BOOST_DURATION = 6.0              # 부스터 지속시간 6초
BOOST_MULTIPLIER = 1.30           # 부스터: 속도 30% 증가
STUN_DURATION = 3.0               # 상대 경직 3초
CHASE_TRIGGER_TIME = 15.0        # 남은 15초에 추격 이벤트 시작
CHASE_SPEED_BONUS = 0.10         # 경찰에게 기본 속도의 10% 추가
CHASE_NOTICE_DURATION = 3.0     # 이벤트 시작 알림 표시 시간

BG = (17, 23, 35)
PANEL = (27, 35, 51)
ROAD = (246, 248, 251)
WALL = (120, 126, 135)
WALL_EDGE = (94, 102, 113)
ROAD_MARK = (213, 219, 227)
POLICE_BLUE = (42, 158, 245)
THIEF_RED = (239, 64, 76)
BOOST_GREEN = (31, 184, 91)
STUN_GOLD = (239, 172, 57)
WHITE = (246, 250, 255)
MUTED = (161, 173, 192)
PORTAL_COLORS = {
    "red": (250, 72, 82),
    "blue": (29, 166, 251),
    "green": (38, 194, 105),
    "purple": (176, 92, 204),
}


@dataclass(frozen=True)
class Portal:
    name: str
    area: pygame.Rect
    exit_pos: tuple[int, int]
    exit_dir: tuple[int, int]


@dataclass(frozen=True)
class MapSpec:
    name: str
    walls: tuple[pygame.Rect, ...]
    portals: tuple[Portal, ...]
    police_start: tuple[int, int]
    thief_start: tuple[int, int]
    police_direction: tuple[int, int] = (0, 1)
    thief_direction: tuple[int, int] = (0, -1)


def create_map(name, walls, portals, police_start, thief_start,
               police_direction=(0, 1), thief_direction=(0, -1)):
    """벽 데이터와 (색, x, y, w, h, 출구x, 출구y, 방향x, 방향y) 데이터로 맵 생성."""
    return MapSpec(
        name=name,
        walls=tuple(pygame.Rect(*data) for data in walls),
        portals=tuple(
            Portal(color, pygame.Rect(x, y, w, h), (out_x, out_y), (dx, dy))
            for color, x, y, w, h, out_x, out_y, dx, dy in portals
        ),
        police_start=police_start,
        thief_start=thief_start,
        police_direction=police_direction,
        thief_direction=thief_direction,
    )


# 맵 1: 기존 기본 맵은 벽과 텔레포트 좌표를 변경하지 않았습니다.
MAP_1 = create_map(
    "기본 맵",
    [
        (0, 0, 310, 90), (380, 0, 490, 90), (940, 0, 565, 90),
        (1590, 0, 170, 90),
        (0, 150, 310, 365), (380, 150, 800, 155),
        (380, 365, 170, 145), (620, 358, 550, 142),
        (1260, 150, 130, 350), (1500, 145, 150, 160),
        (1500, 365, 150, 210),
        (0, 575, 415, 105), (490, 575, 385, 105),
        (940, 575, 710, 105),
    ],
    [
        ("red", 320, 12, 50, 62, 908, 542, 1, 0),
        ("red", 882, 608, 51, 66, 345, 118, 0, 1),
        ("blue", 880, 12, 50, 62, 452, 542, 1, 0),
        ("blue", 426, 608, 53, 66, 906, 120, 1, 0),
        ("green", 1515, 12, 63, 62, 80, 119, 1, 0),
        ("green", 6, 100, 48, 45, 1543, 118, -1, 0),
        ("purple", 6, 526, 48, 43, 1705, 537, 0, -1),
        ("purple", 1670, 608, 80, 66, 80, 548, 1, 0),
    ],
    (345, 331), (1444, 337),
)

# 맵 2: 왼쪽 골목을 넓히고 중앙/오른쪽 장벽을 재배치한 변형.
MAP_2 = create_map(
    "우회로 맵",
    [
        (0, 0, 280, 90), (350, 0, 450, 90),
        (870, 0, 575, 90), (1535, 0, 225, 90),
        (0, 160, 280, 342),
        (360, 160, 690, 145), (360, 375, 200, 145),
        (650, 360, 500, 145), (1260, 165, 170, 325),
        (1510, 165, 140, 160), (1510, 380, 140, 195),
        (0, 575, 390, 105), (470, 575, 520, 105),
        (1060, 575, 600, 105),
    ],
    [
        ("red", 290, 12, 50, 62, 1023, 545, 1, 0),
        ("red", 1000, 608, 55, 66, 315, 125, 0, 1),
        ("blue", 810, 12, 50, 62, 430, 548, 1, 0),
        ("blue", 405, 608, 51, 66, 835, 125, 0, 1),
        ("green", 1460, 12, 58, 62, 80, 125, 1, 0),
        ("green", 6, 100, 48, 45, 1485, 125, -1, 0),
        ("purple", 6, 528, 48, 43, 1700, 540, 0, -1),
        ("purple", 1674, 608, 74, 66, 80, 545, 1, 0),
    ],
    (315, 331), (1465, 337),
)

# 맵 3: 중앙 교차로와 오른쪽 통로 형태를 조금 다르게 배치한 변형.
MAP_3 = create_map(
    "교차로 맵",
    [
        (0, 0, 420, 90), (495, 0, 505, 90),
        (1080, 0, 470, 90), (1635, 0, 125, 90),
        (0, 165, 365, 350),
        (430, 165, 690, 135), (1200, 165, 120, 120),
        (430, 380, 170, 135), (680, 390, 570, 125),
        (1350, 165, 100, 315),
        (1530, 165, 135, 180), (1530, 405, 135, 170),
        (0, 575, 510, 105), (590, 575, 375, 105),
        (1035, 575, 630, 105),
    ],
    [
        ("red", 432, 12, 51, 62, 997, 544, 1, 0),
        ("red", 975, 608, 52, 66, 459, 126, 0, 1),
        ("blue", 1010, 12, 58, 62, 547, 545, 1, 0),
        ("blue", 522, 608, 55, 66, 1038, 126, 0, 1),
        ("green", 1564, 12, 58, 62, 80, 128, 1, 0),
        ("green", 6, 102, 48, 43, 1592, 127, -1, 0),
        ("purple", 6, 527, 48, 44, 1707, 539, 0, -1),
        ("purple", 1681, 608, 69, 66, 80, 546, 1, 0),
    ],
    (397, 335), (1490, 358),
)

# 맵 4: 사용자가 제공한 map2.png를 직선 도로/직각 벽으로 정리했습니다.
# 원본 구조: 위/중앙/아래 가로 도로, 중앙 연결 골목, 오른쪽 세로 도로.
# 빨강 포털은 위↔아래, 파랑 포털은 왼쪽 위↔왼쪽 아래 연결됩니다.
# 다른 세 맵과 달리 새 맵에는 빨강/파랑 2쌍만 존재합니다.
MAP_4 = create_map(
    "이중 포털 맵",
    [
        # 바깥쪽 위쪽 벽 / 오른쪽 벽
        (0, 0, 1460, 59), (1545, 0, 215, 680),
        # 위쪽 두 개의 큰 장애물, 중앙 연결로가 뚫려 있음
        (0, 113, 515, 138),
        (604, 110, 860, 105), (604, 215, 370, 34),
        # 중앙의 세 장애물, 두 세로 통로는 열린 상태
        (0, 321, 565, 166), (655, 318, 335, 169),
        (1065, 267, 400, 220),
        # 아래쪽 장애물: 가운데 세로 연결로와 오른쪽 포털 진입로
        (0, 552, 786, 128), (878, 552, 600, 128),
    ],
    [
        # (색, x, y, 폭, 높이, 도착 x, 도착 y, 도착 후 진행 방향)
        ("blue", 7, 61, 49, 50, 95, 520, 1, 0),
        ("blue", 7, 489, 49, 61, 95, 87, 1, 0),
        ("red", 1466, 3, 72, 55, 1509, 607, 0, -1),
        ("red", 1480, 610, 57, 63, 1509, 92, 0, 1),
    ],
    (145, 519), (1509, 325),
    police_direction=(1, 0),
    thief_direction=(0, -1),
)

MAPS = (MAP_1, MAP_2, MAP_3, MAP_4)


@dataclass(frozen=True)
class Layout:
    screen_w: int
    screen_h: int
    scale: float
    map_x: int
    map_y: int
    header_h: int
    footer_h: int
    ui_scale: float

    def to_screen(self, point):
        return (round(self.map_x + point[0] * self.scale),
                round(self.map_y + point[1] * self.scale))


def compute_layout(screen_w, screen_h):
    """모니터 해상도에 맞춰 종횡비를 유지하며 맵과 HUD 배치."""
    ui = min(screen_w / 1440.0, screen_h / 720.0)
    header = max(70, round(100 * ui))
    footer = max(57, round(72 * ui))
    gap = max(12, round(24 * ui))
    scale = min(
        (screen_w - gap * 2) / WORLD_W,
        (screen_h - header - footer - gap) / WORLD_H,
    )
    scale = max(0.15, scale)
    map_x = round((screen_w - WORLD_W * scale) / 2)
    map_y = header + round((screen_h - header - footer - WORLD_H * scale) / 2)
    return Layout(screen_w, screen_h, scale, map_x, map_y, header, footer, ui)


class Car:
    def __init__(self, start, direction, color, label, level):
        self.pos = pygame.Vector2(start)
        self.direction = direction
        self.color = color
        self.label = label
        self.level = level
        self.teleport_cooldown = 0.0
        self.boost_left = 0.0
        self.stun_left = 0.0
        self.chase_active = False  # 최후 15초에는 경찰만 가속

    @property
    def move_speed(self):
        """부스터와 추격 이벤트의 속도 증가량을 합산 (둘 다 적용 시 +40%)."""
        bonus = (BOOST_MULTIPLIER - 1.0) if self.boost_left > 0 else 0.0
        if self.label == "경찰" and self.chase_active:
            bonus += CHASE_SPEED_BONUS
        return CAR_SPEED * (1.0 + bonus)

    @staticmethod
    def hitbox_at(x, y):
        half = CAR_HITBOX / 2
        return pygame.Rect(round(x - half), round(y - half), CAR_HITBOX, CAR_HITBOX)

    @property
    def hitbox(self):
        return self.hitbox_at(self.pos.x, self.pos.y)

    def can_stand(self, x, y):
        rect = self.hitbox_at(x, y)
        return (rect.left >= 0 and rect.top >= 0
                and rect.right <= WORLD_W and rect.bottom <= WORLD_H
                and not any(rect.colliderect(wall) for wall in self.level.walls))

    def update(self, dt):
        self.teleport_cooldown = max(0.0, self.teleport_cooldown - dt)
        was_stunned = self.stun_left > 0
        self.stun_left = max(0.0, self.stun_left - dt)
        speed = self.move_speed
        self.boost_left = max(0.0, self.boost_left - dt)
        if was_stunned:
            return

        dx, dy = self.direction
        next_x = self.pos.x + dx * speed * dt
        next_y = self.pos.y + dy * speed * dt
        # 벽에 닿으면 정지. 다른 방향을 입력하면 다시 전진.
        if self.can_stand(next_x, next_y):
            self.pos.update(next_x, next_y)

        if self.teleport_cooldown <= 0:
            for portal in self.level.portals:
                if self.hitbox.colliderect(portal.area):
                    if self.can_stand(*portal.exit_pos):
                        self.pos.update(*portal.exit_pos)
                        self.direction = portal.exit_dir
                        self.teleport_cooldown = PORTAL_COOLDOWN
                    break

    def draw(self, screen, font, layout):
        x, y = layout.to_screen(self.pos)
        dx, dy = self.direction
        horizontal = dx != 0
        w = max(10, round((34 if horizontal else 22) * layout.scale))
        h = max(10, round((22 if horizontal else 34) * layout.scale))
        rect = pygame.Rect(0, 0, w, h)
        rect.center = (x, y)

        if self.stun_left > 0:
            pygame.draw.rect(screen, STUN_GOLD, rect.inflate(10, 10), 3, border_radius=7)
        elif self.boost_left > 0:
            pygame.draw.rect(screen, BOOST_GREEN, rect.inflate(10, 10), 3, border_radius=7)

        pygame.draw.rect(screen, (20, 29, 42), rect.move(2, 3), border_radius=4)
        pygame.draw.rect(screen, self.color, rect, border_radius=4)
        pygame.draw.rect(screen, WHITE, rect, 2, border_radius=4)

        # 앞유리: 차량이 바라보는 방향
        if dx == 1:
            pygame.draw.line(screen, WHITE, (rect.right - 6, y - 4), (rect.right - 6, y + 4), 3)
        elif dx == -1:
            pygame.draw.line(screen, WHITE, (rect.left + 6, y - 4), (rect.left + 6, y + 4), 3)
        elif dy == 1:
            pygame.draw.line(screen, WHITE, (x - 4, rect.bottom - 6), (x + 4, rect.bottom - 6), 3)
        else:
            pygame.draw.line(screen, WHITE, (x - 4, rect.top + 6), (x + 4, rect.top + 6), 3)

        label_image = font.render(self.label, True, (24, 32, 45))
        offset = max(25, round(37 * layout.scale))
        label_rect = label_image.get_rect(center=(x, y - offset if self.label == "경찰" else y + offset))
        label_bg = label_rect.inflate(12, 5)
        map_rect = pygame.Rect(layout.map_x, layout.map_y,
                               round(WORLD_W * layout.scale), round(WORLD_H * layout.scale))
        label_bg.clamp_ip(map_rect)
        label_rect.center = label_bg.center
        pygame.draw.rect(screen, WHITE, label_bg, border_radius=5)
        pygame.draw.rect(screen, self.color, label_bg, 2, border_radius=5)
        screen.blit(label_image, label_rect)


@dataclass
class Item:
    kind: str
    pos: tuple[int, int]
    remaining: float = ITEM_LIFETIME

    @property
    def hitbox(self):
        half = ITEM_HITBOX // 2
        return pygame.Rect(self.pos[0] - half, self.pos[1] - half,
                           ITEM_HITBOX, ITEM_HITBOX)

    def draw(self, screen, icon_font, layout):
        x, y = layout.to_screen(self.pos)
        k = max(0.7, min(1.45, layout.scale))
        if self.kind == "booster":
            bg = pygame.Rect(0, 0, round(56 * k), round(47 * k))
            bg.center = (x, y)
            pygame.draw.rect(screen, (223, 252, 231), bg, border_radius=8)
            pygame.draw.rect(screen, BOOST_GREEN, bg, 2, border_radius=8)
            pts = [
                (x, y - round(19 * k)), (x + round(13 * k), y - round(6 * k)),
                (x + round(6 * k), y - round(6 * k)), (x + round(6 * k), y + round(3 * k)),
                (x - round(6 * k), y + round(3 * k)), (x - round(6 * k), y - round(6 * k)),
                (x - round(13 * k), y - round(6 * k)),
            ]
            pygame.draw.polygon(screen, BOOST_GREEN, pts)
            word = icon_font.render("booster", True, (19, 111, 56))
            screen.blit(word, word.get_rect(center=(x, y + round(14 * k))))
        else:
            # 검은 외곽선 + 흰색 원판의 시계 아이콘
            r = round(19 * k)
            pygame.draw.circle(screen, WHITE, (x, y), r)
            pygame.draw.circle(screen, (16, 19, 23), (x, y), r, max(2, round(4 * k)))
            pygame.draw.line(screen, (16, 19, 23), (x, y), (x, y - round(11 * k)), 3)
            pygame.draw.line(screen, (16, 19, 23), (x, y),
                             (x + round(9 * k), y + round(5 * k)), 3)
            pygame.draw.circle(screen, (16, 19, 23), (x, y), max(2, round(3 * k)))


def find_item_spawn(level, cars):
    """현재 맵의 유효한 도로 위에만 아이템 배치."""
    margin = 29
    for _ in range(3000):
        x = random.randint(margin, WORLD_W - margin)
        y = random.randint(margin, WORLD_H - margin)
        area = pygame.Rect(x - margin, y - margin, margin * 2, margin * 2)
        if any(area.colliderect(wall) for wall in level.walls):
            continue
        if any(area.colliderect(portal.area) for portal in level.portals):
            continue
        if any(car.pos.distance_to((x, y)) < 95 for car in cars):
            continue
        return (x, y)
    return None


def make_font(size, bold=False):
    """Windows/한국어 환경에서 한글이 깨지지 않도록 글꼴 선택."""
    for name in (
        "malgungothic", "nanumgothic", "nanumsquare", "notosanscjkkr",
        "notosanskr", "applegothic", "undotum", "baekmukdotum",
        "arial", "dejavusans",
    ):
        path = pygame.font.match_font(name, bold=bold)
        if path:
            return pygame.font.Font(path, size)
    return pygame.font.Font(None, size)


def build_map_surface(level, layout):
    """선택된 맵을 월드 해상도로 그린 뒤 화면에 맞게 1회 축소/확대."""
    surface = pygame.Surface((WORLD_W, WORLD_H)).convert()
    surface.fill(ROAD)

    for cy in (120, 333, 547):
        for cx in range(24, WORLD_W - 15, 54):
            pygame.draw.line(surface, ROAD_MARK, (cx, cy), (cx + 22, cy), 2)

    for wall in level.walls:
        pygame.draw.rect(surface, WALL, wall)
        pygame.draw.rect(surface, WALL_EDGE, wall, 2)

    portal_font = make_font(21, bold=True)
    abbreviations = {"red": "R", "blue": "B", "green": "G", "purple": "P"}
    for portal in level.portals:
        color = PORTAL_COLORS[portal.name]
        translucent = pygame.Surface(portal.area.size, pygame.SRCALPHA)
        translucent.fill((*color, 65))
        surface.blit(translucent, portal.area.topleft)
        pygame.draw.rect(surface, color, portal.area, 4, border_radius=8)
        letter = portal_font.render(abbreviations[portal.name], True, color)
        surface.blit(letter, letter.get_rect(center=portal.area.center))

    pygame.draw.rect(surface, (43, 52, 67), surface.get_rect(), 5)
    return pygame.transform.smoothscale(
        surface, (round(WORLD_W * layout.scale), round(WORLD_H * layout.scale))
    )


def draw_text(surface, font, text, color, pos, anchor="topleft"):
    rendered = font.render(text, True, color)
    surface.blit(rendered, rendered.get_rect(**{anchor: pos}))


def new_game(previous_map_index=None):
    """매 판 랜덤 맵 선택. 직전과 동일한 맵은 연속 선택하지 않음."""
    indexes = [i for i in range(len(MAPS)) if i != previous_map_index]
    index = random.choice(indexes)
    level = MAPS[index]
    police = Car(level.police_start, level.police_direction, POLICE_BLUE, "경찰", level)
    thief = Car(level.thief_start, level.thief_direction, THIEF_RED, "도둑", level)
    return index, level, police, thief


# ────────────────── 솔로모드: 길찾기 AI ──────────────────
# 모든 판단은 플레이어와 동일한 도로/벽/포털 규칙을 사용합니다.
GRID_STEP = 20
GRID_COLS = WORLD_W // GRID_STEP
GRID_ROWS = WORLD_H // GRID_STEP


class RoadNavigator:
    """벽 충돌을 고려한 20px 도로 그래프. 포털은 목적지로 연결된 간선입니다."""

    def __init__(self, level):
        self.level = level
        self.cells = []
        self.links = {}
        self.portals_at = {}
        for r in range(GRID_ROWS):
            for c in range(GRID_COLS):
                x, y = self.xy((c, r))
                box = Car.hitbox_at(x, y)
                if (box.left >= 0 and box.top >= 0 and
                        box.right <= WORLD_W and box.bottom <= WORLD_H and
                        not any(box.colliderect(w) for w in level.walls)):
                    self.cells.append((c, r))
        self.valid = set(self.cells)

        for c, r in self.cells:
            neighbors = [neighbor for neighbor in
                         ((c+1, r), (c-1, r), (c, r+1), (c, r-1))
                         if neighbor in self.valid]
            x, y = self.xy((c, r))
            box = Car.hitbox_at(x, y)
            for portal in level.portals:
                if box.colliderect(portal.area):
                    exit_node = self.nearest_node(portal.exit_pos)
                    if exit_node is not None and exit_node not in neighbors:
                        neighbors.append(exit_node)
                    self.portals_at[(c, r)] = portal
                    break
            self.links[(c, r)] = tuple(neighbors)

    @staticmethod
    def xy(node):
        return (node[0] * GRID_STEP + GRID_STEP / 2,
                node[1] * GRID_STEP + GRID_STEP / 2)

    def nearest_node(self, position):
        c = round((position[0] - GRID_STEP / 2) / GRID_STEP)
        r = round((position[1] - GRID_STEP / 2) / GRID_STEP)
        root = (c, r)
        if root in self.valid:
            return root
        for radius in range(1, 13):
            options = []
            for dc in range(-radius, radius+1):
                for dr in range(-radius, radius+1):
                    if max(abs(dc), abs(dr)) != radius:
                        continue
                    node = (c+dc, r+dr)
                    if node in self.valid:
                        px, py = self.xy(node)
                        options.append(((px-position[0])**2 + (py-position[1])**2, node))
            if options:
                return min(options)[1]
        return None

    def distances(self, start):
        distances = {start: 0} if start is not None else {}
        queue = deque([start]) if start is not None else deque()
        while queue:
            here = queue.popleft()
            d = distances[here] + 1
            for nxt in self.links[here]:
                if nxt not in distances:
                    distances[nxt] = d
                    queue.append(nxt)
        return distances

    def route(self, start, goal):
        if start is None or goal is None:
            return []
        parents = {start: None}
        queue = deque([start])
        while queue and goal not in parents:
            here = queue.popleft()
            for nxt in self.links[here]:
                if nxt not in parents:
                    parents[nxt] = here
                    queue.append(nxt)
        if goal not in parents:
            return []
        path = []
        node = goal
        while node is not None:
            path.append(node)
            node = parents[node]
        path.reverse()
        return path


class AIController:
    """경찰은 상대를 향해 길찾기, 도둑은 추격자에게서 멀어지는 경로를 선택."""

    def __init__(self, level, role):
        self.nav = RoadNavigator(level)
        self.role = role  # "police" 또는 "thief"
        self.path = []
        self.think_left = 0.0
        self.flee_goal = None
        self.flee_goal_left = 0.0

    def select_flee_goal(self, car, opponent):
        start = self.nav.nearest_node(car.pos)
        hunter = self.nav.nearest_node(opponent.pos)
        reachable = self.nav.distances(start)
        threat_dist = self.nav.distances(hunter)
        # 멀리 떨어진 길뿐 아니라 포털을 통한 도주도 선택 대상에 포함.
        options = []
        for node, travel in reachable.items():
            if not (9 <= travel <= 48):
                continue
            away = threat_dist.get(node, 170)
            # 경찰 근처 목적지, 벽으로 막힌 막다른 길은 가급적 피합니다.
            if away < 9:
                continue
            degree = len(self.nav.links[node])
            score = away * 1.05 - travel * 0.60 + random.random() * 6
            if degree <= 1:
                score -= 7
            options.append((score, node))
        if options:
            return max(options)[1]
        return max(reachable, key=reachable.get, default=start)

    def plan(self, car, opponent, item):
        start = self.nav.nearest_node(car.pos)
        target = self.nav.nearest_node(opponent.pos)
        if start is None:
            self.path = []
            return

        if self.role == "police":
            goal = target
            self.think_left = 0.42
        else:
            if self.flee_goal is None or self.flee_goal_left <= 0 or start == self.flee_goal:
                self.flee_goal = self.select_flee_goal(car, opponent)
                self.flee_goal_left = 2.7
            goal = self.flee_goal
            self.think_left = 0.60

        # 수집 가능한 아이템이 가깝다면 AI도 획득을 시도합니다.
        if item is not None and car.stun_left <= 0:
            item_goal = self.nav.nearest_node(item.pos)
            if item_goal is not None:
                item_path = self.nav.route(start, item_goal)
                steps = len(item_path) - 1
                travel_time = steps * GRID_STEP / car.move_speed
                dist_to_enemy = car.pos.distance_to(opponent.pos)
                max_steps = 11 if self.role == "police" else 15
                if (item_path and 0 <= steps <= max_steps and
                        travel_time < item.remaining - 0.35 and
                        (self.role == "police" or dist_to_enemy > 200)):
                    goal = item_goal

        path = self.nav.route(start, goal)
        if not path and self.role == "thief":
            self.flee_goal_left = 0
            path = self.nav.route(start, self.select_flee_goal(car, opponent))
        self.path = path

    def move(self, car, opponent, item, dt):
        self.think_left -= dt
        self.flee_goal_left -= dt
        if self.think_left <= 0 or not self.path:
            self.plan(car, opponent, item)

        if car.stun_left > 0 or not self.path:
            car.update(dt)
            return

        # 남은 프레임 시간에 맞춰 각 격자점을 지나므로 AI도 인간과
        # 똑같은 속도로 직진하며 코너에서는 방향만 전환합니다.
        remaining = dt
        for _ in range(12):
            if remaining <= 1e-6:
                return
            if not self.path:
                car.update(remaining)
                return

            node = self.path[0]
            tx, ty = self.nav.xy(node)
            delta_x = tx - car.pos.x
            delta_y = ty - car.pos.y

            if abs(delta_x) <= 0.15 and abs(delta_y) <= 0.15:
                car.pos.update(tx, ty)
                self.path.pop(0)
                continue

            if abs(delta_x) > 35 or abs(delta_y) > 35:
                # 순간이동 간선: 포털 안쪽으로 진입하면 Car.update가 이동 처리.
                portal = self.nav.portals_at.get(self.nav.nearest_node(car.pos))
                if portal is not None:
                    px, py = portal.area.center
                    dx, dy = px - car.pos.x, py - car.pos.y
                    if abs(dx) >= abs(dy):
                        car.direction = (1 if dx >= 0 else -1, 0)
                    else:
                        car.direction = (0, 1 if dy >= 0 else -1)
                old = car.pos.copy()
                car.update(remaining)
                if car.pos.distance_to(old) > car.move_speed * remaining + 35:
                    self.path = []
                    self.think_left = 0
                return

            if abs(delta_x) > 0.15:
                car.direction = (1 if delta_x > 0 else -1, 0)
                travel = abs(delta_x)
            else:
                car.direction = (0, 1 if delta_y > 0 else -1)
                travel = abs(delta_y)

            speed = car.move_speed
            step_dt = min(remaining, travel / speed)
            before = car.pos.copy()
            car.update(step_dt)
            remaining -= step_dt
            moved = car.pos.distance_to(before)

            # 포털 이동 또는 벽 막힘 발생 시 다음 프레임에 경로 재탐색.
            if moved > speed * step_dt + 35 or (moved < 0.04 and step_dt > 0.0001):
                self.path = []
                self.think_left = 0
                if remaining > 0:
                    car.update(remaining)
                return

            if travel <= speed * step_dt + 0.15:
                if abs(delta_x) > 0.15:
                    car.pos.x = tx
                else:
                    car.pos.y = ty

        if remaining > 0:
            car.update(remaining)

def effect_text(car):
    effects = []
    if car.boost_left > 0:
        effects.append(f"부스터 {car.boost_left:.1f}초")
    if car.stun_left > 0:
        effects.append(f"경직 {car.stun_left:.1f}초")
    return "  /  ".join(effects) if effects else "효과 없음"


def main():
    pygame.init()
    pygame.display.set_caption("경찰과 도둑 | 솔로 AI / 2인 멀티 추격전")

    # 모니터 전체 화면. ESC는 어떤 화면에서든 즉시 게임을 종료합니다.
    info = pygame.display.Info()
    desktop_size = (info.current_w or 1440, info.current_h or 720)
    screen = pygame.display.set_mode(desktop_size, pygame.FULLSCREEN)
    sw, sh = screen.get_size()
    layout = compute_layout(sw, sh)
    ui = layout.ui_scale
    clock = pygame.time.Clock()

    big_font = make_font(max(25, round(47 * ui)), bold=True)
    title_font = make_font(max(19, round(30 * ui)), bold=True)
    font = make_font(max(15, round(21 * ui)), bold=True)
    small_font = make_font(max(13, round(17 * ui)))
    tag_font = make_font(max(13, round(16 * ui)), bold=True)
    item_font = make_font(max(10, round(13 * max(0.7, min(1.45, layout.scale)))), bold=True)
    button_font = make_font(max(19, round(28 * ui)), bold=True)

    map_surfaces = [build_map_surface(level, layout) for level in MAPS]
    map_index, level, police, thief = new_game()
    state = "menu"     # menu -> choose_role -> ready -> running -> finished
    mode = None        # "solo" 또는 "multi"
    player_role = None # solo에서 "police" 또는 "thief"
    ai = None
    time_left = ROUND_TIME
    winner = ""
    item = None
    spawn_elapsed = 0.0
    chase_notice_left = 0.0
    buttons = []

    police_keys = {
        pygame.K_w: (0, -1), pygame.K_a: (-1, 0),
        pygame.K_s: (0, 1), pygame.K_d: (1, 0),
    }
    thief_keys = {
        pygame.K_UP: (0, -1), pygame.K_LEFT: (-1, 0),
        pygame.K_DOWN: (0, 1), pygame.K_RIGHT: (1, 0),
    }

    def reset_round():
        nonlocal map_index, level, police, thief, ai, state
        nonlocal time_left, winner, item, spawn_elapsed, chase_notice_left
        map_index, level, police, thief = new_game(map_index)
        ai = None
        if mode == "solo":
            ai_role = "thief" if player_role == "police" else "police"
            ai = AIController(level, ai_role)
        time_left = ROUND_TIME
        winner = ""
        item = None
        spawn_elapsed = 0.0
        chase_notice_left = 0.0
        state = "ready"

    def activate(action):
        nonlocal state, mode, player_role
        if action == "solo":
            mode = "solo"
            state = "choose_role"
        elif action == "multi":
            mode = "multi"
            player_role = None
            reset_round()
        elif action in ("police", "thief"):
            mode = "solo"
            player_role = action
            reset_round()
        elif action == "start" and state == "ready":
            state = "running"
        elif action == "again" and state == "finished":
            reset_round()
            state = "running"
        elif action == "back":
            if state == "choose_role":
                mode = None
            state = "menu"
        elif action == "menu":
            mode = None
            player_role = None
            state = "menu"

    def draw_button(rect, label, action, accent, subtitle=None):
        hovered = rect.collidepoint(pygame.mouse.get_pos())
        fill = tuple(min(255, c + (24 if hovered else 0)) for c in accent)
        if hovered:
            pygame.draw.rect(screen, fill, rect.move(0, 4), border_radius=13)
        pygame.draw.rect(screen, fill, rect, border_radius=13)
        pygame.draw.rect(screen, WHITE, rect, 2, border_radius=13)
        if subtitle:
            draw_text(screen, button_font, label, WHITE,
                      (rect.centerx, rect.y + round(9 * ui)), "midtop")
            draw_text(screen, small_font, subtitle, (238, 241, 248),
                      (rect.centerx, rect.bottom - round(22 * ui)), "midtop")
        else:
            draw_text(screen, button_font, label, WHITE, rect.center, "center")
        buttons.append((rect, action))

    while True:
        dt = min(clock.tick(FPS) / 1000.0, 0.05)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    return
                if event.key == pygame.K_m and state not in ("menu", "choose_role"):
                    activate("menu")
                elif event.key == pygame.K_r and state in ("ready", "running", "finished"):
                    reset_round()
                elif event.key == pygame.K_SPACE and state == "ready":
                    activate("start")
                elif event.key == pygame.K_1 and state == "menu":
                    activate("solo")
                elif event.key == pygame.K_2 and state == "menu":
                    activate("multi")
                elif event.key == pygame.K_1 and state == "choose_role":
                    activate("police")
                elif event.key == pygame.K_2 and state == "choose_role":
                    activate("thief")
                elif state == "running":
                    # 솔로: 고르지 않은 역할은 AI가 자동 조작.
                    if (event.key in police_keys and police.stun_left <= 0 and
                            (mode == "multi" or player_role == "police")):
                        police.direction = police_keys[event.key]
                    elif (event.key in thief_keys and thief.stun_left <= 0 and
                          (mode == "multi" or player_role == "thief")):
                        thief.direction = thief_keys[event.key]
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for rect, action in buttons:
                    if rect.collidepoint(event.pos):
                        activate(action)
                        break

        if state == "running":
            previous_time = time_left
            time_left = max(0.0, time_left - dt)
            # 정확히 남은 15초에 한 번 발동하며, 경기 종료/재시작 시 초기화.
            if previous_time > CHASE_TRIGGER_TIME >= time_left:
                chase_notice_left = CHASE_NOTICE_DURATION
            chase_notice_left = max(0.0, chase_notice_left - dt)
            police.chase_active = 0 < time_left <= CHASE_TRIGGER_TIME
            if time_left > 0:
                if mode == "solo" and ai is not None:
                    if player_role == "police":
                        police.update(dt)
                        ai.move(thief, police, item, dt)
                    else:
                        ai.move(police, thief, item, dt)
                        thief.update(dt)
                else:
                    police.update(dt)
                    thief.update(dt)

                if police.hitbox.colliderect(thief.hitbox):
                    state, winner = "finished", "경찰 승리!"
                else:
                    if item is not None:
                        item.remaining -= dt
                        if item.remaining <= 0:
                            item = None

                    spawn_elapsed += dt
                    if spawn_elapsed >= ITEM_SPAWN_INTERVAL:
                        spawn_elapsed -= ITEM_SPAWN_INTERVAL
                        place = find_item_spawn(level, (police, thief))
                        if place is not None:
                            item = Item(random.choice(("booster", "stun")), place)

                    if item is not None:
                        candidates = [car for car in (police, thief)
                                      if car.hitbox.colliderect(item.hitbox)]
                        if candidates:
                            collector = min(candidates,
                                            key=lambda car: car.pos.distance_to(item.pos))
                            opponent = thief if collector is police else police
                            if item.kind == "booster":
                                collector.boost_left = BOOST_DURATION
                            else:
                                opponent.stun_left = STUN_DURATION
                            item = None
            if state == "running" and time_left <= 0:
                state, winner = "finished", "도둑 승리!"

        # ───────────────── 지도 및 상태 표시 ─────────────────
        screen.fill(BG)
        pygame.draw.rect(screen, PANEL, (0, 0, sw, layout.header_h))
        left = layout.map_x
        right = sw - layout.map_x
        pad = max(8, round(18 * ui))
        heading = "경찰  vs  도둑"
        if mode == "solo" and state in ("ready", "running", "finished"):
            heading += "   ·   SOLO"
        elif mode == "multi" and state in ("ready", "running", "finished"):
            heading += "   ·   MULTI"
        draw_text(screen, title_font, heading, WHITE, (left, pad))
        draw_text(screen, small_font,
                  f"{level.name} ({map_index+1}/{len(MAPS)})  |  10초마다 아이템  |  부스터 +30%(6초)  |  상대 경직(3초)",
                  MUTED, (left, max(35, round(60 * ui))))
        timer_color = (255, 104, 113) if police.chase_active and state == "running" else WHITE
        draw_text(screen, big_font, f"{math.ceil(time_left):02d}s", timer_color,
                  (right, max(5, round(12 * ui))), "topright")
        if state == "running":
            if item is not None:
                info_text = f"아이템 사라짐: {item.remaining:.1f}초"
            else:
                info_text = f"다음 아이템: {max(0, ITEM_SPAWN_INTERVAL-spawn_elapsed):.1f}초"
            draw_text(screen, small_font, info_text, MUTED,
                      (right, max(35, round(74 * ui))), "topright")

        screen.blit(map_surfaces[map_index], (layout.map_x, layout.map_y))
        if state == "running" and police.chase_active:
            # 추격 이벤트 시작 시 3초간 큰 알림, 이후에는 작은 표시만 유지.
            banner_font = font if chase_notice_left > 0 else small_font
            notice = ("추격 이벤트!  경찰 속도 +10%"
                      if chase_notice_left > 0 else "추격 중  ·  경찰 +10%")
            label_surface = banner_font.render(notice, True, WHITE)
            banner_w = label_surface.get_width() + round(32 * ui)
            banner_h = label_surface.get_height() + round(16 * ui)
            banner = pygame.Rect(0, 0, banner_w, banner_h)
            banner.midtop = (sw // 2, layout.map_y + max(8, round(12 * ui)))
            pygame.draw.rect(screen, (117, 35, 49), banner, border_radius=10)
            pygame.draw.rect(screen, (255, 115, 120), banner, 2, border_radius=10)
            screen.blit(label_surface, label_surface.get_rect(center=banner.center))
        if item is not None:
            item.draw(screen, item_font, layout)
        police.draw(screen, tag_font, layout)
        thief.draw(screen, tag_font, layout)

        footer_y = sh - layout.footer_h
        pygame.draw.rect(screen, PANEL, (0, footer_y, sw, layout.footer_h))
        x_police = left
        x_thief = left + round(430 * ui)
        pygame.draw.line(screen, (59, 72, 91), (0, footer_y), (sw, footer_y), 1)
        p_user = mode == "solo" and player_role == "police"
        t_user = mode == "solo" and player_role == "thief"
        p_tag = "(나)" if p_user else "(AI)" if mode == "solo" else ""
        t_tag = "(나)" if t_user else "(AI)" if mode == "solo" else ""
        draw_text(screen, font, "경찰 " + p_tag, POLICE_BLUE,
                  (x_police, footer_y + max(6, round(10 * ui))))
        draw_text(screen, small_font, "W A S D" if mode != "solo" or p_user else "자동 조작",
                  WHITE, (x_police + round(120 * ui), footer_y + max(10, round(16 * ui))))
        police_status = effect_text(police)
        if state == "running" and police.chase_active:
            police_status += "  /  추격 +10%" if police_status != "효과 없음" else "추격 +10%"
        draw_text(screen, small_font, police_status,
                  STUN_GOLD if police.stun_left > 0 else BOOST_GREEN if police.boost_left > 0 else (255, 140, 145) if police.chase_active and state == "running" else MUTED,
                  (x_police, footer_y + max(30, round(42 * ui))))
        draw_text(screen, font, "도둑 " + t_tag, THIEF_RED,
                  (x_thief, footer_y + max(6, round(10 * ui))))
        draw_text(screen, small_font, "방향키" if mode != "solo" or t_user else "자동 조작",
                  WHITE, (x_thief + round(120 * ui), footer_y + max(10, round(16 * ui))))
        draw_text(screen, small_font, effect_text(thief),
                  STUN_GOLD if thief.stun_left > 0 else BOOST_GREEN if thief.boost_left > 0 else MUTED,
                  (x_thief, footer_y + max(30, round(42 * ui))))
        draw_text(screen, small_font, "SPACE 시작   R 새 맵   M 모드 선택   ESC 종료",
                  MUTED, (right, footer_y + max(16, round(20 * ui))), "topright")

        # ─────────── 마우스로 클릭 가능한 메뉴 버튼 ───────────
        buttons = []
        if state in ("menu", "choose_role", "ready", "finished"):
            dim = pygame.Surface((sw, sh), pygame.SRCALPHA)
            dim.fill((8, 13, 24, 188))
            screen.blit(dim, (0, 0))
            panel_w = min(sw - 20, round(740 * ui))
            panel_h = min(sh - 20, round(420 * ui))
            panel = pygame.Rect(0, 0, panel_w, panel_h)
            panel.center = (sw // 2, sh // 2)
            pygame.draw.rect(screen, PANEL, panel, border_radius=20)
            pygame.draw.rect(screen, (95, 116, 149), panel, 2, border_radius=20)
            cx = panel.centerx
            gap = round(15 * ui)
            bw = round(270 * ui)
            bh = round(78 * ui)
            btn_y = panel.y + round(208 * ui)
            start_x = cx - bw - gap // 2
            end_x = cx + gap // 2

            if state == "menu":
                draw_text(screen, big_font, "경찰과 도둑", WHITE,
                          (cx, panel.top + round(44 * ui)), "midtop")
                draw_text(screen, font, "플레이할 모드를 선택하세요", MUTED,
                          (cx, panel.top + round(123 * ui)), "midtop")
                draw_button(pygame.Rect(start_x, btn_y, bw, bh),
                            "솔로모드", "solo", (30, 113, 178), "AI와 1대1 대결 · 숫자 1")
                draw_button(pygame.Rect(end_x, btn_y, bw, bh),
                            "멀티모드", "multi", (152, 67, 84), "키보드 2인 대결 · 숫자 2")
                draw_text(screen, small_font, f"맵 {len(MAPS)}종 랜덤  ·  80초 제한  ·  아이템/텔레포트 지원",
                          MUTED, (cx, panel.bottom - round(55 * ui)), "midtop")
            elif state == "choose_role":
                draw_text(screen, big_font, "솔로모드", WHITE,
                          (cx, panel.top + round(44 * ui)), "midtop")
                draw_text(screen, font, "어느 역할을 플레이할까요?", MUTED,
                          (cx, panel.top + round(123 * ui)), "midtop")
                draw_button(pygame.Rect(start_x, btn_y, bw, bh),
                            "경찰 플레이", "police", (30, 113, 178), "WASD 조작 · AI 도둑")
                draw_button(pygame.Rect(end_x, btn_y, bw, bh),
                            "도둑 플레이", "thief", (152, 67, 84), "방향키 조작 · AI 경찰")
                draw_text(screen, small_font, "1: 경찰  ·  2: 도둑  ·  아래 버튼으로 뒤로 가기",
                          MUTED, (cx, panel.bottom - round(58 * ui)), "midtop")
                back = pygame.Rect(0, 0, round(115 * ui), round(38 * ui))
                back.midbottom = (cx, panel.bottom - round(7 * ui))
                pygame.draw.rect(screen, (58, 69, 90), back, border_radius=9)
                draw_text(screen, small_font, "뒤로", WHITE, back.center, "center")
                buttons.append((back, "back"))
            elif state == "ready":
                draw_text(screen, big_font, "출발 준비!", WHITE,
                          (cx, panel.top + round(38 * ui)), "midtop")
                display_mode = "솔로모드" if mode == "solo" else "멀티모드"
                match_label = ("내 역할: 경찰  |  AI: 도둑" if player_role == "police"
                               else "내 역할: 도둑  |  AI: 경찰") if mode == "solo" else "경찰: WASD  |  도둑: 방향키"
                draw_text(screen, font, f"{display_mode}  ·  {level.name}", WHITE,
                          (cx, panel.top + round(114 * ui)), "midtop")
                draw_text(screen, small_font, match_label, MUTED,
                          (cx, panel.top + round(155 * ui)), "midtop")
                draw_button(pygame.Rect(start_x, btn_y, bw, bh),
                            "게임 시작", "start", (31, 134, 89), "클릭 또는 SPACE")
                draw_button(pygame.Rect(end_x, btn_y, bw, bh),
                            "모드 선택", "menu", (67, 83, 108), "시작 화면으로")
                draw_text(screen, small_font, "R: 랜덤 맵 변경  ·  ESC: 게임 종료",
                          MUTED, (cx, panel.bottom - round(55 * ui)), "midtop")
            else:  # finished
                color = POLICE_BLUE if winner.startswith("경찰") else THIEF_RED
                draw_text(screen, big_font, winner, color,
                          (cx, panel.top + round(44 * ui)), "midtop")
                if mode == "solo":
                    human_won = ((player_role == "police" and winner.startswith("경찰"))
                                 or (player_role == "thief" and winner.startswith("도둑")))
                    info_text = "플레이어 승리!" if human_won else "AI 승리!"
                else:
                    info_text = "2인 대결 종료"
                draw_text(screen, font, info_text, WHITE,
                          (cx, panel.top + round(133 * ui)), "midtop")
                draw_button(pygame.Rect(start_x, btn_y, bw, bh),
                            "다시 하기", "again", (31, 134, 89), "새 랜덤 맵으로 시작")
                draw_button(pygame.Rect(end_x, btn_y, bw, bh),
                            "모드 선택", "menu", (67, 83, 108), "다른 모드로 변경")
                draw_text(screen, small_font, "R: 새 맵 준비  ·  M: 모드 선택  ·  ESC: 종료",
                          MUTED, (cx, panel.bottom - round(55 * ui)), "midtop")

        pygame.display.flip()


if __name__ == "__main__":
    main()
