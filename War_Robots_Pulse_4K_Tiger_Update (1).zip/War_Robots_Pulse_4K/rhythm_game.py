"""Four-key rhythm game. Requires pygame 2.5+ and the original MP3."""
from pathlib import Path
import json
import sys
import time
import math
from collections import deque, Counter

try:
    import pygame as pg
except ImportError:
    print('Pygame is required. Run: py -m pip install pygame')
    raise SystemExit(1)

ROOT = Path(__file__).resolve().parent
TRACKS = [
    dict(chart='chart.json', audio='11War robots mainmixed.mp3', cover='main_cover.jpg', background='gameplay_background.jpg', preview='main_preview.ogg', name='War Robots Main Mixed'),
    dict(chart='sword_chart.json', audio='WR sword_mixed.mp3', cover='sword_cover.jpg', background='sword_background.jpg', preview='sword_preview.ogg', name='WR Sword'),
    dict(chart='revolve_chart.json', audio='WR REVOLVE.mp3', cover='revolve_cover.jpg', background='revolve_background.jpg', preview='revolve_preview.ogg', name='WR REVOLVE'),
    dict(chart='tiger_chart.json', audio='A Tiger Among Dragons.mp3', cover='tiger_cover.jpg', background='tiger_background.jpg', preview='tiger_preview.ogg', name='A Tiger Among Dragons'),
]
for track in TRACKS:
    track['data'] = json.loads((ROOT / track['chart']).read_text(encoding='utf-8'))
W, H = 1100, 760
LANE_W, LEFT, HIT_Y = 120, 310, 610
TOP = 100
KEYS = (pg.K_d, pg.K_f, pg.K_j, pg.K_k)
LABELS = ('D', 'F', 'J', 'K')
COLORS = ((84, 205, 255), (123, 151, 255), (255, 146, 194), (255, 194, 100))
BG, WHITE, MUTED = (13, 18, 31), (233, 239, 250), (147, 163, 188)
WINDOW = .155
PARTIAL_COLOR = (211, 174, 255)
MISS_COLOR = (255,106,125)
JUDGES = [('PERFECT', .045, 1000, (122, 239, 255)), ('GREAT', .085, 750, (147, 255, 172)), ('GOOD', WINDOW, 400, (255, 211, 121))]


def text(surface, value, size, x, y, color=WHITE, anchor='topleft', bold=False):
    key = (size, bold)
    if key not in FONTS:
        FONTS[key] = pg.font.SysFont('segoeui', size, bold=bold)
    im = FONTS[key].render(str(value), True, color)
    rect = im.get_rect(); setattr(rect, anchor, (int(x), int(y)))
    surface.blit(im, rect)


def rect(surface, color, x, y, w, h, r=0, border=0):
    pg.draw.rect(surface, color, pg.Rect(int(x), int(y), max(0,int(w)), max(0,int(h))), border, border_radius=r)


def mmss(t):
    t = max(0, int(t)); return f'{t//60:02}:{t%60:02}'


class Game:
    def __init__(self):
        self.selected = 0
        self.ui_anim = {}
        self.ui_press = None
        self.ui_launch = None
        self.data = TRACKS[0]['data']
        self.audio = ROOT / TRACKS[0]['audio']
        self.preview_enabled = True
        self.preview_pending = None
        self.list_scroll = 0.0
        self.state = 'menu'
        self.mode = 1
        self.modes = ['EASY', 'NORMAL', 'HARD']
        self.offset = 0.0
        self.travel = 1.65
        self.volume = .75
        self.error = ''
        self.fullscreen = False
        self.window_size = (W,H)
        self.screen = pg.display.set_mode(self.window_size, pg.RESIZABLE)
        self.canvas = pg.Surface((W, H))
        self.covers = []
        self.backgrounds = []
        self.thumbs = []
        for track in TRACKS:
            try:
                im = pg.image.load(str(ROOT / track['cover'])).convert()
                self.covers.append(pg.transform.smoothscale(im, (444, 249)))
                self.thumbs.append(pg.transform.smoothscale(im, (86, 48)))
            except (pg.error, OSError):
                self.covers.append(None); self.thumbs.append(None)
            try:
                im = pg.image.load(str(ROOT / track['background'])).convert()
                self.backgrounds.append(pg.transform.smoothscale(im, (W,H)))
            except (pg.error, OSError): self.backgrounds.append(None)
        self.play_background = self.backgrounds[0]
        # Cache translucent lane fills to keep notes legible over the picture.
        self.lane_panels = {}
        for color in ((31,44,64), (21,30,46), (24,34,52)):
            panel = pg.Surface((LANE_W, HIT_Y-TOP+22), pg.SRCALPHA)
            panel.fill((*color, 202))
            self.lane_panels[color] = panel
        self.clock = pg.time.Clock()
        self.alive = True
        self.last_judge = ''
        self.last_color = WHITE
        self.judge_until = 0
        self.held = [False]*4
        self.flash = [0.0]*4
        self.music_started = False

        self.preview_pending = time.perf_counter()

    def stop_music(self):
        if pg.mixer.get_init(): pg.mixer.music.stop()

    def select_track(self, index):
        index = max(0, min(len(TRACKS)-1,index))
        if index == self.selected: return
        self.selected = index
        track = TRACKS[index]
        self.data = track['data']; self.audio = ROOT / track['audio']
        self.play_background = self.backgrounds[index]
        self.error = ''
        self.stop_music()
        self.preview_pending = time.perf_counter() + .14 if self.preview_enabled else None

    def toggle_preview(self):
        self.preview_enabled = not self.preview_enabled
        self.stop_music(); self.error = ''
        self.preview_pending = time.perf_counter() if self.preview_enabled else None

    def update_preview(self):
        self.list_scroll += (self.selected-self.list_scroll)*.22
        if self.preview_pending is None or time.perf_counter() < self.preview_pending: return
        self.preview_pending = None
        try:
            if not pg.mixer.get_init(): pg.mixer.init()
            pg.mixer.music.load(str(ROOT / TRACKS[self.selected]['preview']))
            pg.mixer.music.set_volume(self.volume*.8)
            pg.mixer.music.play(-1)
        except (pg.error, OSError) as exc:
            self.error = 'Preview unavailable: ' + str(exc)

    def start(self):
        self.ui_launch=None
        self.ui_press=None
        self.preview_pending = None
        self.stop_music()
        if not self.audio.is_file():
            self.error = 'Audio missing. Extract the entire ZIP.'
            return
        if not pg.mixer.get_init():
            try:
                pg.mixer.init()
            except pg.error as exc:
                self.error = 'Audio device error: ' + str(exc)
                return
        pg.mixer.music.stop()
        try:
            pg.mixer.music.load(str(self.audio))
            pg.mixer.music.set_volume(self.volume)
        except (pg.error, OSError) as exc:
            self.error = str(exc); self.state = 'menu'; return
        self.error = ''
        self.notes = self.data['charts'][self.modes[self.mode]]
        self.lanes = [deque((t, duration) for t,l,duration in self.notes if l==i) for i in range(4)]
        self.active_holds = [None]*4
        self.sample_time = None
        self.hold_covered = 0.0
        self.hold_duration = sum(d for _,_,d in self.notes if d > 0)
        self.hold_completed = 0
        self.hold_total = sum(duration > 0 for _,_,duration in self.notes)
        self.total = len(self.notes)
        self.counts = Counter()
        self.score = self.combo = self.max_combo = self.weight = 0
        self.last_judge = ''
        self.judge_until = 0
        self.last_delta = None
        self.flash = [0.0]*4
        self.held = [False]*4
        self.music_started = False
        self.start_clock = time.perf_counter() + 2.5
        self.paused_at = None
        self.state = 'play'

    def raw_time(self):
        ref = self.paused_at if self.state == 'pause' else time.perf_counter()
        return ref - self.start_clock

    def song_time(self):
        # Positive offset advances the chart clock (earlier note arrival).
        return self.raw_time() + self.offset

    def pause(self):
        self.paused_at = time.perf_counter()
        self.expire(self.paused_at - self.start_clock + self.offset)
        if self.music_started: pg.mixer.music.pause()
        self.held = [False]*4
        self.state = 'pause'

    def resume(self):
        self.start_clock += time.perf_counter() - self.paused_at
        if self.music_started: pg.mixer.music.unpause()
        self.paused_at = None
        self.state = 'play'
        # Paused time is excluded; resume with the currently pressed keys.
        self.held = [bool(pg.key.get_pressed()[k]) for k in KEYS]
        self.sample_time = self.song_time()

    def menu(self):
        self.stop_music()
        self.state = 'menu'
        self.preview_pending = time.perf_counter() if self.preview_enabled else None

    def mark(self, name, points, color, delta=None):
        self.counts[name] += 1
        self.weight += points
        if name in ('MISS', 'PARTIAL'): self.combo = 0
        else:
            self.combo += 1
            self.max_combo = max(self.max_combo, self.combo)
        self.refresh_score()
        self.last_judge, self.last_color = name, color
        self.last_delta = delta
        self.judge_until = time.perf_counter() + .62

    def refresh_score(self):
        pending = sum(1000 * min(1.0, h['covered'] / (h['end'] - h['start']))
                      for h in self.active_holds if h is not None)
        self.score = round(1000000 * (self.weight + pending) / (1000 * self.total))

    def finish_hold(self, lane):
        h = self.active_holds[lane]
        if h is None: return
        self.active_holds[lane] = None
        duration = h['end'] - h['start']
        covered = min(duration, h['covered'])
        self.hold_covered += covered
        fraction = covered / duration
        points = 1000 * fraction
        # Only tiny floating-point rounding error is forgiven.
        if fraction >= 1 - 1e-7:
            self.hold_completed += 1
            self.flash[lane] = time.perf_counter() + .16
            self.mark('PERFECT', 1000, JUDGES[0][3])
        elif covered > 1e-7:
            self.mark('PARTIAL', points, PARTIAL_COLOR)
        else:
            self.mark('MISS', 0, MISS_COLOR)

    def expire(self, now):
        # Integrate the exact overlap of a pressed interval with each hold.
        # Called before every key transition and every frame, so releases and
        # re-presses never remove a hold or award its unpressed segment.
        previous = now if self.sample_time is None else min(now, self.sample_time)
        self.sample_time = now
        for i, queue in enumerate(self.lanes):
            while True:
                h = self.active_holds[i]
                if h is None:
                    if not queue: break
                    t, duration = queue[0]
                    if duration > 0:
                        if now < t: break
                        queue.popleft()
                        h = {'start': t, 'end': t+duration, 'covered': 0.0}
                        self.active_holds[i] = h
                    elif now-t > WINDOW:
                        queue.popleft()
                        self.mark('MISS', 0, MISS_COLOR)
                        continue
                    else: break
                if self.held[i]:
                    h['covered'] += max(0.0, min(now, h['end']) - max(previous, h['start']))
                if now >= h['end']:
                    self.finish_hold(i)
                    continue
                break
        self.refresh_score()

    def release(self, lane):
        self.expire(self.song_time())
        self.held[lane] = False

    def hit(self, lane):
        if self.held[lane]: return
        now = self.song_time()
        self.expire(now)
        self.held[lane] = True
        self.flash[lane] = time.perf_counter() + .11
        if self.active_holds[lane] is not None:
            self.last_judge, self.last_color = 'HOLD', COLORS[lane]
            self.last_delta = None
            self.judge_until = time.perf_counter() + .45
            return
        queue = self.lanes[lane]
        if not queue: return
        t, duration = queue[0]
        if duration > 0: return  # a hold is activated by its timeline, not by a hit
        dt = now - t
        if abs(dt) > WINDOW: return
        queue.popleft()
        for name, limit, points, color in JUDGES:
            if abs(dt) <= limit:
                self.mark(name, points, color, dt)
                break

    def update(self):
        if self.state == 'menu':
            self.update_preview(); return
        if self.state != 'play': return
        if not self.music_started and self.raw_time() >= 0:
            try:
                pg.mixer.music.play()
                self.start_clock = time.perf_counter()
                self.music_started = True
            except pg.error as exc:
                self.error = str(exc); self.state = 'menu'; return
        self.expire(self.song_time())
        if self.raw_time() >= self.data['duration'] + max(.20, .20-self.offset):
            for i, lane in enumerate(self.lanes):
                if self.active_holds[i] is not None:
                    self.finish_hold(i)
                while lane:
                    lane.popleft(); self.mark('MISS', 0, (255,106,125))
            pg.mixer.music.stop()
            self.state = 'result'

    def accuracy(self):
        judged = sum(self.counts.values())
        return 100 * self.weight/(1000*judged) if judged else 100.0

    def ui_mouse(self, pos=None):
        sw,sh=self.screen.get_size(); scale=min(sw/W,sh/H)
        x,y=pg.mouse.get_pos() if pos is None else pos
        return ((x-(sw-W*scale)/2)/scale,(y-(sh-H*scale)/2)/scale)

    def ui_buttons(self):
        buttons=[('play',pg.Rect(39,586,494,67)),('preview',pg.Rect(858,431,184,30)),('minus',pg.Rect(39,505,121,41)),('plus',pg.Rect(410,505,123,41))]
        buttons += [(f'diff{i}',pg.Rect(39,207+i*66,494,58)) for i in range(3)]
        for i in range(len(TRACKS)):
            r=pg.Rect(587,round(573+(i-self.list_scroll)*66-29),413,58).clip(pg.Rect(582,474,424,198))
            if r.height: buttons.append((f'track{i}',r))
        if self.selected>0: buttons.append(('up',pg.Rect(1009,477,46,40)))
        if self.selected<len(TRACKS)-1: buttons.append(('down',pg.Rect(1009,631,46,40)))
        return buttons

    def ui_target(self,pos=None):
        p=self.ui_mouse(pos)
        return next((key for key,r in self.ui_buttons() if r.collidepoint(p)),None)

    def ui_effects(self):
        c=self.canvas; hover=self.ui_target(); now=time.perf_counter()
        dt=min(.05,self.clock.get_time()/1000)
        for key,r in self.ui_buttons():
            a=self.ui_anim.get(key,0.0); target=float(key==hover)
            a += (target-a)*(1-math.exp(-18*dt)); self.ui_anim[key]=a
            pressed=self.ui_press==key and pg.mouse.get_pressed()[0]
            pulse=0.0
            if getattr(self,'ui_last_click',None)==key:
                elapsed=now-self.ui_click_time
                if elapsed<.22: pulse=math.sin(math.pi*elapsed/.22)
            if a<.01 and not pressed and pulse<=0: continue
            original=c.subsurface(r).copy()
            # Scale the rendered button, including its text and artwork.
            scale=1+.025*a-.035*float(pressed)-.025*pulse
            size=(max(1,round(r.w*scale)),max(1,round(r.h*scale)))
            im=pg.transform.smoothscale(original,size); dest=im.get_rect(center=r.center)
            oldclip=c.get_clip()
            if key.startswith('track'): c.set_clip(pg.Rect(582,474,424,198))
            c.blit(im,dest); pg.draw.rect(c,(244,197,42),dest,2,border_radius=5)
            if pulse>0: pg.draw.rect(c,(255,235,145),dest.inflate(4,4),1,border_radius=6)
            c.set_clip(oldclip)

    def event(self, e):
        if e.type == pg.QUIT: self.alive = False; return
        if e.type == pg.VIDEORESIZE and not self.fullscreen:
            self.window_size = (max(480,e.w), max(340,e.h)); self.screen = pg.display.set_mode(self.window_size, pg.RESIZABLE)
        if self.state == 'menu' and e.type == pg.MOUSEWHEEL:
            self.select_track(self.selected - e.y)
        if self.state == 'menu' and e.type == pg.MOUSEBUTTONDOWN and e.button == 1:
            self.ui_press=self.ui_target(e.pos)
        if self.state == 'menu' and e.type == pg.MOUSEBUTTONUP and e.button == 1:
            key=self.ui_target(e.pos); pressed=self.ui_press; self.ui_press=None
            if key and key==pressed and self.ui_launch is None:
                self.ui_last_click=key; self.ui_click_time=time.perf_counter()
                if key=='play': self.ui_launch=self.ui_click_time+.16
                elif key=='preview': self.toggle_preview()
                elif key=='minus': self.travel=max(.85,round(self.travel-.15,2))
                elif key=='plus': self.travel=min(3.,round(self.travel+.15,2))
                elif key=='up': self.select_track(self.selected-1)
                elif key=='down': self.select_track(self.selected+1)
                elif key.startswith('diff'): self.mode=int(key[4:])
                elif key.startswith('track'): self.select_track(int(key[5:]))
        if e.type == pg.KEYUP and e.key in KEYS:
            lane = KEYS.index(e.key)
            if self.state == 'play': self.release(lane)
            else: self.held[lane] = False
        if e.type == getattr(pg,'WINDOWFOCUSLOST',-1) and self.state == 'play': self.pause()
        if e.type != pg.KEYDOWN: return
        k = e.key
        if k == pg.K_F11:
            self.fullscreen = not self.fullscreen
            self.screen = pg.display.set_mode((0,0),pg.FULLSCREEN) if self.fullscreen else pg.display.set_mode(self.window_size,pg.RESIZABLE)
            return
        if self.state == 'menu':
            if k == pg.K_ESCAPE: self.alive = False
            elif k in (pg.K_LEFT,pg.K_RIGHT): self.mode = (self.mode + (-1 if k==pg.K_LEFT else 1))%3
            elif k == pg.K_UP: self.select_track(self.selected-1)
            elif k == pg.K_DOWN: self.select_track(self.selected+1)
            elif k == pg.K_LEFTBRACKET: self.travel = max(.85, round(self.travel-.15,2))
            elif k == pg.K_RIGHTBRACKET: self.travel = min(3.0, round(self.travel+.15,2))
            elif k == pg.K_p: self.toggle_preview()
            elif k in (pg.K_MINUS,pg.K_KP_MINUS): self.offset = max(-.4,round(self.offset-.01,2))
            elif k in (pg.K_EQUALS,pg.K_PLUS,pg.K_KP_PLUS): self.offset = min(.4,round(self.offset+.01,2))
            elif k == pg.K_RETURN: self.start()
        elif self.state == 'play':
            if k in KEYS: self.hit(KEYS.index(k))
            elif k == pg.K_ESCAPE: self.pause()
        elif self.state == 'pause':
            if k in (pg.K_ESCAPE,pg.K_RETURN): self.resume()
            elif k == pg.K_r: self.start()
            elif k == pg.K_m: self.menu()
        elif self.state == 'result':
            if k in (pg.K_RETURN,pg.K_r): self.start()
            elif k in (pg.K_ESCAPE,pg.K_m): self.menu()

    def draw_menu(self):
        # Hangar-inspired navy/steel-blue lobby; gameplay palette stays unchanged.
        c=self.canvas
        hover=self.ui_target()
        panel=(17,30,47); card=(24,43,64)
        edge=(58,82,108); yellow=(244,197,42); gold=(196,157,42)
        white=(240,246,252); muted=(146,171,194); ink=(15,25,37)
        steel=(89,141,181); blue=(32,61,86); active_blue=(36,66,94)
        if not hasattr(self, 'hangar_lobby'):
            bg=pg.Surface((W,H)).convert()
            for y in range(H):
                t=y/(H-1)
                col=tuple(round(a+(b-a)*t) for a,b in zip((17,32,53),(6,14,26)))
                pg.draw.line(bg,col,(0,y),(W,y))
            # Overhead gantry, structural uprights and recessed light strips.
            for x in (0,290,810,1100):
                pg.draw.polygon(bg,(20,39,60),[(x-45,0),(x+45,0),(x+21,500),(x-21,500)])
                pg.draw.line(bg,(37,64,89),(x+45,0),(x+21,500),2)
            pg.draw.polygon(bg,(12,24,40),[(0,0),(W,0),(W,19),(0,49)])
            for x in (65,350,635,920):
                rect(bg,(36,75,108),x,7,115,3,1)
            # Perspective floor seams: subdued, behind the interface.
            for x in range(-500,1700,145):
                pg.draw.line(bg,(24,43,63),(550,475),(x,H),1)
            for y in (685,707,734,757):
                pg.draw.line(bg,(29,48,68),(0,y),(W,y),1)
            self.hangar_lobby=bg
        c.blit(self.hangar_lobby,(0,0))
        rect(c,steel,0,0,W,3)
        rect(c,yellow,0,0,164,3)
        rect(c,yellow,25,24,7,76)
        text(c,'PULSE',46,43,18,white,bold=True)
        text(c,'/ 4K',46,207,18,steel,bold=True)
        text(c,'WAR ROBOTS  /  HANGAR  /  STAGE SELECT',17,43,79,muted,bold=True)
        text(c,'TRACK',13,1058,23,muted,'topright',True)
        text(c,f'{self.selected+1:02d} / {len(TRACKS):02d}',30,1058,41,yellow,'topright',True)
        for x in range(900,949,18):
            pg.draw.polygon(c,steel,[(x,88),(x+10,88),(x+22,100),(x+12,100)])
        pg.draw.line(c,edge,(25,112),(1075,112),2)
        pg.draw.line(c,yellow,(25,112),(165,112),2)
        for x,w in [(25,527),(568,507)]:
            rect(c,panel,x,133,w,551,8)
            rect(c,edge,x,133,w,551,8,1)
            rect(c,steel,x+1,134,w-2,2,1)
            rect(c,yellow,x+1,134,72,2,1)
            # Small clipped-corner inspired hangar panel details.
            pg.draw.lines(c,steel,False,[(x+w-36,145),(x+w-12,145),(x+w-12,160)],1)
            pg.draw.lines(c,edge,False,[(x+12,660),(x+12,674),(x+36,674)],1)
        text(c,'01  /  DIFFICULTY',18,39,151,yellow,bold=True)
        text(c,self.data['title'],27,39,177,white,bold=True)
        for i,mode in enumerate(self.modes):
            y=207+i*66; active=i==self.mode
            rect(c,(15,16,19) if hover==f'diff{i}' else active_blue if active else card,39,y,494,58,5)
            rect(c,yellow if active else edge,39,y,494,58,5,2 if active else 1)
            rect(c,yellow if active else steel,46,y+9,4,40,1)
            text(c,mode,23,59,y+28,yellow if active or hover==f'diff{i}' else white,'midleft',True)
            n=self.data['charts'][mode]
            text(c,f'{len(n)} notes  /  {sum(v[2]>0 for v in n)} holds',17,518,y+28,white if active else muted,'midright',active)
        text(c,'PLAY FIELD  /  4 KEYS',16,39,420,yellow,bold=True)
        for i,k in enumerate(LABELS):
            x=40+i*124
            rect(c,card,x,444,116,50,5)
            rect(c,edge,x,444,116,50,5,1)
            rect(c,steel,x+5,488,106,3,1)
            text(c,k,26,x+58,468,white,'center',True)
        rect(c,card,39,505,494,41,5)
        rect(c,edge,39,505,494,41,5,1)
        if hover in ('minus','plus'):
            rect(c,(15,16,19),39 if hover=='minus' else 410,505,121 if hover=='minus' else 123,41,5)
        text(c,'[-]',21,57,525,yellow,'midleft',True)
        text(c,'[+]',21,516,525,yellow,'midright',True)
        text(c,f'Note travel  {self.travel:.2f}s   [ / ]',18,286,525,white,'center')
        text(c,f'Audio sync  {self.offset*1000:+.0f} ms   (- / +)',16,39,559,muted)
        rect(c,(15,16,19) if hover=='play' else blue,39,586,494,67,5)
        rect(c,yellow,39,586,494,67,5,2)
        rect(c,yellow,39,598,5,43,1)
        pg.draw.polygon(c,yellow,[(68,607),(68,631),(87,619)])
        text(c,'PLAY  /  ENTER',29,286,619,yellow if hover=='play' else white,'center',True)
        for x in (487,501,515):
            pg.draw.polygon(c,yellow,[(x,595),(x+5,595),(x-9,644),(x-14,644)])
        text(c,'02  /  SONG SELECT',18,588,151,yellow,bold=True)
        if self.covers[self.selected] is not None: c.blit(self.covers[self.selected],(598,179))
        else: rect(c,card,598,179,444,249,5)
        rect(c,steel,597,178,446,251,2,2)
        shade=pg.Surface((444,62),pg.SRCALPHA); shade.fill((9,22,38,230)); c.blit(shade,(598,366))
        rect(c,steel,598,366,444,2)
        text(c,self.data['title'],24,610,371,white,bold=True)
        text(c,f"{self.data['bpm']:.0f} BPM   /   {mmss(self.data['duration']+.5)}",16,610,402,yellow)
        text(c,'SCROLL / UP / DOWN',16,590,449,muted,'midleft',True)
        rect(c,(15,16,19) if hover=='preview' else blue if self.preview_enabled else card,858,431,184,30,5)
        rect(c,yellow if self.preview_enabled else edge,858,431,184,30,5,1)
        text(c,'PREVIEW ON [P]' if self.preview_enabled else 'PREVIEW OFF [P]',15,950,446,yellow if self.preview_enabled else muted,'center',True)
        c.set_clip(pg.Rect(582,474,424,198))
        for i,track in enumerate(TRACKS):
            y=round(573+(i-self.list_scroll)*66-29); active=i==self.selected
            rect(c,(15,16,19) if hover==f'track{i}' else active_blue if active else card,587,y,413,58,5)
            rect(c,yellow if active else edge,587,y,413,58,5,2 if active else 1)
            if active: rect(c,yellow,588,y+4,4,50,1)
            if self.thumbs[i] is not None: c.blit(self.thumbs[i],(594,y+5))
            text(c,f'{i+1:02d}',15,690,y+12,yellow if active else muted,bold=active)
            text(c,track['name'],19,719,y+10,white,bold=active)
            td=track['data']; text(c,f"{td['bpm']:.0f} BPM / {mmss(td['duration']+.5)}",15,719,y+34,yellow if active else muted)
        c.set_clip(None)
        for y,up,enabled in [(477,True,self.selected>0),(631,False,self.selected<len(TRACKS)-1)]:
            rect(c,(15,16,19) if hover==('up' if up else 'down') else blue if enabled else card,1009,y,46,40,5)
            rect(c,steel if enabled else edge,1009,y,46,40,5,1)
            cy=y+20; delta=-1 if up else 1
            pg.draw.lines(c,white if enabled else muted,False,[(1023,cy-4*delta),(1032,cy+5*delta),(1041,cy-4*delta)],3)
        rect(c,edge,1029,525,5,98,2)
        rect(c,yellow,1029,525+50*self.selected/max(1,len(TRACKS)-1),5,48,2)
        pg.draw.line(c,edge,(25,698),(1075,698),1)
        status=self.error or 'LEFT / RIGHT  Difficulty     •     F11  Fullscreen     •     ESC  Exit'
        text(c,status[:110],16,550,719,white if self.error else muted,'center')
        rect(c,steel,0,H-3,W,3)
        rect(c,yellow,W-125,H-3,125,3)

    def draw_play(self):
        c=self.canvas
        if self.play_background is None:
            c.fill(BG)
        else:
            c.blit(self.play_background, (0, 0))
        now=self.song_time(); raw=self.raw_time(); wall=time.perf_counter()
        text(c,'PULSE / 4K',29,32,25,WHITE,bold=True)
        text(c,self.modes[self.mode],18,34,62,MUTED)
        text(c,self.data['title'],21,W/2,29,WHITE,'midtop',True)
        text(c,f'{mmss(raw)} / {mmss(self.data["duration"])}',18,W/2,60,MUTED,'midtop')
        rect(c,(36,46,63),LEFT,87,480,5,2)
        rect(c,COLORS[0],LEFT,87,480*min(1,max(0,raw/self.data['duration'])),5,2)
        speed=(HIT_Y-TOP)/self.travel
        # Clip notes to the playfield so they never overlap the HUD.
        c.set_clip(pg.Rect(LEFT,TOP,LANE_W*4, HIT_Y-TOP+22))
        for i in range(4):
            x=LEFT+i*LANE_W
            lit=self.held[i] or wall<self.flash[i]
            lane_color = (31,44,64) if lit else ((21,30,46) if i%2==0 else (24,34,52))
            if self.play_background is None:
                rect(c,lane_color,x,TOP,LANE_W,HIT_Y-TOP+22)
            else:
                c.blit(self.lane_panels[lane_color], (x, TOP))
            pg.draw.line(c,(51,64,85),(x,TOP),(x,HIT_Y+22),1)
        # Quiet beat lines based on the measured tempo and grid phase.
        beat=60/self.data['bpm']; phase=self.data.get('beat_phase',.0756); first=math.floor((now-phase)/beat)
        for b in range(first,first+int(self.travel/beat)+3):
            t=phase + b*beat
            y=HIT_Y-(t-now)*speed
            if TOP <= y <= HIT_Y+22: pg.draw.line(c,(44,55,74),(LEFT,int(y)),(LEFT+480,int(y)),1)
        for i,q in enumerate(self.lanes):
            x=LEFT+i*LANE_W
            color=COLORS[i]
            body=tuple(int(v*.52) for v in color)
            for t,duration in q:
                if t-now>self.travel+.1: break
                y=HIT_Y-(t-now)*speed
                if duration > 0:
                    tail=HIT_Y-(t+duration-now)*speed
                    if y>=TOP-20 and tail<=HIT_Y+22:
                        # Draw only the visible part of the long body.
                        a,b=max(TOP,tail),min(HIT_Y+22,y)
                        if b>a:
                            rect(c,body,x+25,a,LANE_W-50,b-a,5)
                            rect(c,color,x+25,a,LANE_W-50,b-a,5,2)
                        if TOP-12<=tail<=HIT_Y+22:
                            rect(c,color,x+19,tail-5,LANE_W-38,10,4)
                if TOP-20<=y<=HIT_Y+22:
                    rect(c,color,x+8,y-9,LANE_W-16,18,5)
                    rect(c,WHITE,x+13,y-7,LANE_W-26,3,1)
            active=self.active_holds[i]
            if active is not None:
                t,end=active['start'],active['end']
                tail=HIT_Y-(end-now)*speed
                a=max(TOP,min(HIT_Y,tail))
                fill=color if self.held[i] else body
                rect(c,fill,x+23,a,LANE_W-46,HIT_Y-a,5)
                rect(c,color,x+23,a,LANE_W-46,HIT_Y-a,5,2)
                rect(c,WHITE if self.held[i] else color,x+9,HIT_Y-9,LANE_W-18,18,5)
                if TOP<=tail<=HIT_Y:
                    rect(c,color,x+17,tail-5,LANE_W-34,10,4)
        c.set_clip(None)
        pg.draw.line(c,(220,234,255),(LEFT,HIT_Y),(LEFT+480,HIT_Y),3)
        for i in range(4):
            x=LEFT+i*LANE_W; lit=self.held[i] or wall<self.flash[i]
            rect(c,COLORS[i] if lit else (27,40,58),x+6,642,LANE_W-12,69,9)
            rect(c,COLORS[i],x+6,642,LANE_W-12,69,9,2)
            text(c,LABELS[i],32,x+LANE_W/2,676,BG if lit else COLORS[i],'center',True)
        text(c,'SCORE',17,40,141,MUTED); text(c,f'{self.score:07,}',33,40,168,WHITE,bold=True)
        text(c,'ACCURACY',17,40,238,MUTED); text(c,f'{self.accuracy():.2f}%',30,40,265,WHITE,bold=True)
        text(c,'MAX COMBO',17,40,335,MUTED); text(c,self.max_combo,30,40,361,WHITE,bold=True)
        text(c,'COMBO',18,855,155,MUTED); text(c,self.combo,52,855,181,WHITE,bold=True)
        for i,(name,col) in enumerate([('PERFECT',JUDGES[0][3]),('GREAT',JUDGES[1][3]),('GOOD',JUDGES[2][3]),('PARTIAL',PARTIAL_COLOR),('MISS',(255,106,125))]):
            text(c,name,16,850,300+40*i,col); text(c,self.counts[name],19,1059,300+40*i,WHITE,'topright',True)
        if raw<0:
            text(c,str(max(1,math.ceil(-raw))),90,W/2,330,WHITE,'center',True)
        elif wall<self.judge_until:
            text(c,self.last_judge,40,W/2,276,self.last_color,'center',True)
            if self.last_delta is not None:
                text(c,f'{self.last_delta*1000:+.0f} ms',18,W/2,318,WHITE,'center')
        text(c,'D F J K   /   Hold or re-press long notes to earn points   /   ESC Pause',16,W/2,735,MUTED,'center')
        for i,active in enumerate(self.active_holds):
            if active is not None:
                start,end=active['start'],active['end']
                x=LEFT+i*LANE_W
                progress=min(1,max(0,active['covered']/(end-start)))
                rect(c,(36,46,63),x+10,716,LANE_W-20,5,2)
                rect(c,COLORS[i],x+10,716,(LANE_W-20)*progress,5,2)

    def draw_pause(self):
        self.draw_play()
        shade=pg.Surface((W,H),pg.SRCALPHA); shade.fill((0,0,0,180)); self.canvas.blit(shade,(0,0))
        c=self.canvas
        rect(c,(25,36,54),320,220,460,300,15)
        text(c,'PAUSED',46,W/2,278,WHITE,'center',True)
        text(c,'ENTER / ESC   Resume',24,W/2,356,WHITE,'center')
        text(c,'R   Restart',24,W/2,413,MUTED,'center')
        text(c,'M   Main menu',24,W/2,462,MUTED,'center')

    def draw_result(self):
        c=self.canvas; c.fill(BG)
        acc=self.accuracy(); grade='S' if acc>=95 else 'A' if acc>=85 else 'B' if acc>=70 else 'C' if acc>=55 else 'D'
        text(c,'TRACK COMPLETE  /  '+self.data['title'],22,W/2,58,MUTED,'center',True)
        text(c,grade,112,W/2,155,COLORS[0],'center',True)
        text(c,f'{self.score:,} / 1,000,000',39,W/2,242,WHITE,'center',True)
        text(c,f'{acc:.2f}%  ACCURACY    /    {self.max_combo}  MAX COMBO',23,W/2,298,MUTED,'center')
        for i,(name,col) in enumerate([('PERFECT',JUDGES[0][3]),('GREAT',JUDGES[1][3]),('GOOD',JUDGES[2][3]),('PARTIAL',PARTIAL_COLOR),('MISS',(255,106,125))]):
            y=326+i*46; rect(c,(24,34,50),315,y,470,40,8)
            text(c,name,21,334,y+22,col,'midleft',True)
            text(c,self.counts[name],23,764,y+22,WHITE,'midright',True)
        text(c,f'FULL HOLDS  {self.hold_completed} / {self.hold_total}    /    HOLD COVERAGE  {100*self.hold_covered/max(1e-9,self.hold_duration):.1f}%',18,W/2,618,MUTED,'center')
        if self.counts['MISS']==0 and self.counts['PARTIAL']==0: text(c,'FULL COMBO',25,W/2,583,COLORS[3],'center',True)
        text(c,'ENTER / R  Retry     •     ESC / M  Main menu',20,W/2,665,WHITE,'center')

    def run(self):
        while self.alive:
            for e in pg.event.get(): self.event(e)
            if not self.alive: break
            if self.state=='menu' and self.ui_launch is not None and time.perf_counter()>=self.ui_launch: self.start()
            self.update()
            if self.state=='menu':
                self.draw_menu(); self.ui_effects()
            elif self.state=='play': self.draw_play()
            elif self.state=='pause': self.draw_pause()
            else: self.draw_result()
            sw,sh=self.screen.get_size(); scale=min(sw/W,sh/H); size=(max(1,int(W*scale)),max(1,int(H*scale)))
            self.screen.fill((7,10,17))
            self.screen.blit(pg.transform.smoothscale(self.canvas,size),((sw-size[0])//2,(sh-size[1])//2))
            pg.display.flip(); self.clock.tick(120)
        pg.quit()


FONTS={}
if __name__=='__main__':
    pg.mixer.pre_init(44100,-16,2,512)
    pg.init()
    pg.display.set_caption('War Robots | PULSE 4K')
    Game().run()
