PULSE 4K - Stage Select Update (D F J K)

1. ZIP 전체를 압축 해제하고 Start_Game.bat를 실행합니다.
   Python 3와 Pygame이 필요합니다. 없으면 py -3 -m pip install pygame
2. 위/아래 방향키, 마우스 휠 또는 곡 목록 클릭으로 곡을 선택합니다.
3. 좌/우 방향키 또는 난이도 클릭으로 EASY / NORMAL / HARD를 선택합니다.
4. ENTER 또는 PLAY 버튼을 클릭하면 선택한 곡이 처음부터 재생됩니다.
5. 로비에서는 선택된 곡의 24초 미리듣기가 반복됩니다. P 또는 PREVIEW 버튼으로 켜고 끌 수 있습니다.
6. [ / ] 키 또는 노트 속도 버튼으로 낙하 시간 조절, - / + 키로 싱크 조절.
7. D F J K 타격 / ESC 일시정지 / F11 전체화면 / R 재시작 / M 로비 복귀.

곡 1: War Robots Main Mixed (기존 125 BPM 채보와 음원 유지)
곡 2: WR Sword (약 1:49, 180 BPM 그리드, 별도 멜로디 믹스 WR sword_other_mixed.mp3 기반 채보, 실제 재생 WR sword_mixed.mp3)
WR Sword 커버와 인게임 배경은 사용자가 제공한 이미지로 교체되었습니다. 인게임 배경에 약한 블러와 밝기 감소를 적용했습니다.
음원, 채보, 이미지, 미리듣기는 모두 동봉되어 파일 선택이 필요 없습니다.

롱노트는 놓치거나 도중에 떼어도 꼬리가 판정선에 도달할 때까지 유지됩니다.
실제로 누른 시간만큼 점수가 실시간으로 올라갑니다. 일부 누르면 PARTIAL, 전혀 누르지 않으면 MISS.
일시정지 시간은 판정에 포함되지 않습니다. 각 난이도 최대 점수는 100만 점입니다.
새 곡의 채보는 자동 분석을 기반으로 하며 일부 반주 음에 대응할 수 있습니다.

WR Sword HARD: 400 -> 600 notes (기존 400개 유지, 멜로디 온셋 및 동시 입력 200개 추가). EASY/NORMAL 및 기존 음원 유지.

곡 3: WR REVOLVE (2.45분, 약 113.0 BPM 분석값). 사용자가 제공한 음원 및 이미지로 제작.
EASY: 220 notes / 23 holds, NORMAL: 400 notes / 26 holds, HARD: 760 notes / 38 holds
24초 미리듣기 및 인게임 블러 배경 포함.

War Robots Theme Update: 로비에 검정/노랑/흰색 테마 적용. 기존 게임 화면, 채보, 판정, 음원 및 조작 유지.

Hangar Theme Update: 로비를 남색/짙은 파랑 및 스틸 블루 중심으로 변경. 노란색은 선택 표시와 PLAY 버튼 테두리 등 강조 요소에 사용. 게임 플레이와 음원/채보는 이전과 동일.


곡 4: A Tiger Among Dragons (약 4:06, 반복 박자 약 154 BPM 추정, 실제 음원 온셋 기반 채보).
EASY 350 / NORMAL 650 / HARD 1320 notes. 원본 음원, 커버, 흐릿한 배경, 24초 미리듣기 포함.
기존 격납고 테마와 버튼 애니메이션 유지.
