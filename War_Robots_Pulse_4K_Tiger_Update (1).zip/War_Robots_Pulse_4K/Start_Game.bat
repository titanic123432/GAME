@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 -c "import sys" >nul 2>nul
    if not errorlevel 1 goto usepy
)
where python >nul 2>nul
if not errorlevel 1 goto usepython
echo Python 3 not found. Install Python 3 and try again.
pause
exit /b 1
:usepy
set "PY=py -3"
goto check
:usepython
set "PY=python"
:check
%PY% -c "import pygame" >nul 2>nul
if errorlevel 1 (
    echo Pygame is missing. Run this command in CMD:
    echo %PY% -m pip install pygame
    pause
    exit /b 1
)
%PY% rhythm_game.py %*
if errorlevel 1 (
    echo.
    echo The game encountered an error. Copy the message above.
    pause
)
